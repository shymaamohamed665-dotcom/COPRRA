<?php return array (
  'App\\Providers\\EventServiceProvider' => 
  array (
  ),
  'Illuminate\\Foundation\\Support\\Providers\\EventServiceProvider' => 
  array (
    'App\\Events\\OrderStatusChanged' => 
    array (
      0 => 'App\\Listeners\\SendOrderStatusNotification@handle',
    ),
  ),
);