<?php

declare(strict_types=1);

namespace App\Services\Backup\Strategies;

use App\Services\Backup\Services\BackupConfigurationService;
use Exception;

final readonly class ConfigurationBackupStrategy implements BackupStrategyInterface
{
    private BackupConfigurationService $configurationService;

    public function __construct(BackupConfigurationService $configurationService)
    {
        $this->configurationService = $configurationService;
    }

    /**
     * {@inheritdoc}
     */
    #[\Override]
    public function backup(string $backupDir, string $backupName): array
    {
        try {
            return $this->configurationService->backupConfiguration($backupDir);
        } catch (Exception $e) {
            throw new Exception("Configuration backup failed: {$e->getMessage()}", 0, $e);
        }
    }

    /**
     * {@inheritdoc}
     */
    #[\Override]
    public function restore(string $backupPath, array $backupInfo): array
    {
        try {
            return $this->configurationService->restoreConfiguration($backupPath, $backupInfo);
        } catch (Exception $e) {
            throw new Exception("Configuration restoration failed: {$e->getMessage()}", 0, $e);
        }
    }

    /**
     * @psalm-return 'config'
     */
    #[\Override]
    public function getComponentName(): string
    {
        return 'config';
    }

    /**
     * {@inheritdoc}
     */
    #[\Override]
    public function canHandle(array $backupInfo): bool
    {
        return isset($backupInfo['files']) &&
               isset($backupInfo['size']) &&
               isset($backupInfo['status']);
    }
}
