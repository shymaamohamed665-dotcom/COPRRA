<?php

declare(strict_types=1);

return [
    // Development server URL used by CSP during local environment
    'dev_server' => env('VITE_DEV_SERVER', 'http://localhost:5173'),
];
