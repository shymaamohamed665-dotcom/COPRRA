<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array<int, string>
     */
    protected $except = [
        'api/*',
    ];

    /**
     * Skip CSRF verification entirely during unit/feature tests.
     */
    #[\Override]
    public function handle($request, \Closure $next)
    {
        if (app()->runningUnitTests()) {
            return $next($request);
        }

        return parent::handle($request, $next);
    }
}
