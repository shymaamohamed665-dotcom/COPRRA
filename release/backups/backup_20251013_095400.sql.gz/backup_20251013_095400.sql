-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: db    Database: laravel
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `analytics_events`
--

DROP TABLE IF EXISTS `analytics_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `analytics_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `analytics_events_event_type_created_at_index` (`event_type`,`created_at`),
  KEY `analytics_events_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `analytics_events_product_id_created_at_index` (`product_id`,`created_at`),
  KEY `analytics_events_created_at_index` (`created_at`),
  KEY `analytics_events_event_type_index` (`event_type`),
  KEY `analytics_events_session_id_index` (`session_id`),
  CONSTRAINT `analytics_events_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `analytics_events`
--

LOCK TABLES `analytics_events` WRITE;
/*!40000 ALTER TABLE `analytics_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `analytics_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `auditable_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_auditable_type_auditable_id_index` (`auditable_type`,`auditable_id`),
  KEY `audit_logs_user_id_index` (`user_id`),
  KEY `audit_logs_event_index` (`event`),
  KEY `audit_logs_created_at_index` (`created_at`),
  KEY `audit_logs_event_created_at_index` (`event`,`created_at`),
  KEY `audit_logs_ip_address_index` (`ip_address`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brands` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `brands_slug_unique` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_items`
--

DROP TABLE IF EXISTS `cart_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `quantity` int unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_items_user_id_index` (`user_id`),
  KEY `cart_items_product_id_index` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_items`
--

LOCK TABLES `cart_items` WRITE;
/*!40000 ALTER TABLE `cart_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `cart_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` bigint unsigned DEFAULT NULL,
  `level` int NOT NULL DEFAULT '1',
  `description` text COLLATE utf8mb4_unicode_ci,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`),
  KEY `categories_slug_index` (`slug`),
  KEY `categories_parent_id_index` (`parent_id`),
  CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currencies`
--

DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currencies` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `exchange_rate` decimal(10,4) NOT NULL DEFAULT '1.0000',
  `decimal_places` int NOT NULL DEFAULT '2',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `currencies_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currencies`
--

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_notifications`
--

DROP TABLE IF EXISTS `custom_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `custom_notifications` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` json DEFAULT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `sent_at` timestamp NULL DEFAULT NULL,
  `priority` int NOT NULL DEFAULT '2',
  `channel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'database',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `metadata` json DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `custom_notifications_user_id_index` (`user_id`),
  KEY `custom_notifications_type_index` (`type`),
  KEY `custom_notifications_status_index` (`status`),
  KEY `custom_notifications_priority_index` (`priority`),
  KEY `custom_notifications_channel_index` (`channel`),
  KEY `custom_notifications_sent_at_index` (`sent_at`),
  KEY `custom_notifications_created_at_index` (`created_at`),
  KEY `custom_notifications_user_id_read_at_index` (`user_id`,`read_at`),
  KEY `custom_notifications_user_id_status_index` (`user_id`,`status`),
  KEY `custom_notifications_type_status_index` (`type`,`status`),
  CONSTRAINT `custom_notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_notifications`
--

LOCK TABLES `custom_notifications` WRITE;
/*!40000 ALTER TABLE `custom_notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `custom_notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exchange_rates`
--

DROP TABLE IF EXISTS `exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `exchange_rates` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from_currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `to_currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` decimal(20,10) NOT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `fetched_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `exchange_rates_from_currency_to_currency_unique` (`from_currency`,`to_currency`),
  KEY `exchange_rates_from_currency_to_currency_updated_at_index` (`from_currency`,`to_currency`,`updated_at`),
  KEY `exchange_rates_from_currency_index` (`from_currency`),
  KEY `exchange_rates_to_currency_index` (`to_currency`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange_rates`
--

LOCK TABLES `exchange_rates` WRITE;
/*!40000 ALTER TABLE `exchange_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language_currency`
--

DROP TABLE IF EXISTS `language_currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `language_currency` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `language_id` bigint unsigned NOT NULL,
  `currency_id` bigint unsigned NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `language_currency_language_id_currency_id_unique` (`language_id`,`currency_id`),
  KEY `language_currency_currency_id_foreign` (`currency_id`),
  CONSTRAINT `language_currency_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `language_currency_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language_currency`
--

LOCK TABLES `language_currency` WRITE;
/*!40000 ALTER TABLE `language_currency` DISABLE KEYS */;
/*!40000 ALTER TABLE `language_currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `native_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `direction` enum('ltr','rtl') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ltr',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `languages_code_unique` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2018_08_08_100000_create_telescope_entries_table',1),(5,'2019_12_14_000001_create_personal_access_tokens_table',1),(6,'2024_09_27_000000_add_password_confirmed_at_to_users_table',1),(7,'2024_10_01_000002_create_analytics_events_table',1),(8,'2025_01_15_000002_add_encrypted_fields',1),(9,'2025_01_15_000003_create_audit_logs_table',1),(10,'2025_01_15_000004_create_notifications_table',1),(11,'2025_02_01_000001_create_cart_items_table',1),(12,'2025_02_01_000002_alter_notifications_add_user_id',1),(13,'2025_08_18_145450_create_brands_table',1),(14,'2025_08_18_145451_create_categories_table',1),(15,'2025_08_18_145452_create_products_table',1),(16,'2025_08_18_145453_create_languages_and_currencies_tables',1),(17,'2025_08_18_145454_create_stores_table',1),(18,'2025_08_21_180931_create_price_offers_table',1),(19,'2025_08_21_184616_create_reviews_table',1),(20,'2025_08_21_184634_create_wishlists_table',1),(21,'2025_08_21_184657_create_price_alerts_table',1),(22,'2025_09_07_055316_add_image_to_products_table',1),(23,'2025_09_07_073043_add_is_admin_to_users_table',1),(24,'2025_09_08_000000_add_role_to_users_table',1),(25,'2025_09_08_025634_add_soft_deletes_to_brands_table',1),(26,'2025_09_08_025841_add_soft_deletes_to_categories_table',1),(27,'2025_09_08_030119_add_soft_deletes_to_stores_table',1),(28,'2025_09_08_030214_add_description_to_stores_table',1),(29,'2025_09_08_030254_add_logo_url_to_stores_table',1),(30,'2025_09_08_030441_add_affiliate_code_to_stores_table',1),(31,'2025_09_08_030534_add_store_id_to_products_table',1),(32,'2025_09_08_030823_add_soft_deletes_to_price_alerts_table',1),(33,'2025_09_08_041809_add_soft_deletes_to_products_table',1),(34,'2025_09_08_042807_add_decimal_places_to_currencies_table',1),(35,'2025_09_08_064338_add_is_available_and_original_price_to_price_offers_table',1),(36,'2025_09_10_064350_add_ban_fields_to_users_table',1),(37,'2025_09_11_233947_add_session_id_to_users_table',1),(38,'2025_09_14_065423_create_permission_tables',1),(39,'2025_09_19_033122_add_stock_quantity_to_products_table',1),(40,'2025_09_19_033158_add_is_active_to_users_table',1),(41,'2025_09_20_000000_add_is_featured_to_products_table',1),(42,'2025_09_21_225510_add_currency_to_price_offers_table',1),(43,'2025_09_21_225619_recreate_price_offers_table',1),(44,'2025_09_25_155133_create_custom_notifications_table',1),(45,'2025_09_25_185824_create_orders_table',1),(46,'2025_09_25_185845_create_order_items_table',1),(47,'2025_09_25_185900_create_payment_methods_table',1),(48,'2025_09_25_185904_create_payments_table',1),(49,'2025_09_25_185925_create_rewards_table',1),(50,'2025_09_25_185943_create_user_points_table',1),(51,'2025_09_25_190659_create_user_behaviors_table',1),(52,'2025_09_30_000001_add_performance_indexes',2),(53,'2025_10_01_000001_create_exchange_rates_table',2),(54,'2025_10_01_000003_create_webhooks_table',2),(55,'2025_10_02_000000_create_price_histories_table',2),(56,'2025_10_08_000001_add_phone_and_email_validation_to_users_table',2),(57,'2025_10_08_000002_add_order_date_validation_to_orders_table',2),(58,'2025_10_09_163500_add_currency_id_to_products_table',2),(59,'2025_10_09_163600_create_product_store_pivot_table',2),(60,'2025_10_09_163700_add_quantity_to_products_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`),
  KEY `notifications_created_at_index` (`created_at`),
  KEY `notifications_notifiable_type_notifiable_id_read_at_index` (`notifiable_type`,`notifiable_id`,`read_at`),
  KEY `notifications_user_id_index` (`user_id`),
  KEY `notifications_notifiable_index` (`notifiable_type`,`notifiable_id`),
  KEY `notifications_read_at_index` (`read_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `product_details` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_product_id_index` (`order_id`,`product_id`),
  KEY `order_items_order_id_index` (`order_id`),
  KEY `order_items_product_id_index` (`product_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `status` enum('pending','processing','shipped','delivered','cancelled','refunded','completed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `total_amount` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `shipping_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `shipping_address` json NOT NULL,
  `billing_address` json NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `shipped_at` timestamp NULL DEFAULT NULL,
  `delivered_at` timestamp NULL DEFAULT NULL,
  `order_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_number_unique` (`order_number`),
  KEY `orders_user_id_status_index` (`user_id`,`status`),
  KEY `orders_user_id_index` (`user_id`),
  KEY `orders_status_index` (`status`),
  KEY `orders_order_number_index` (`order_number`),
  KEY `orders_user_status_index` (`user_id`,`status`),
  KEY `orders_created_at_index` (`created_at`),
  CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_methods`
--

DROP TABLE IF EXISTS `payment_methods`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_methods` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gateway` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `config` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_methods_gateway_is_active_index` (`gateway`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_methods`
--

LOCK TABLES `payment_methods` WRITE;
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `payment_method_id` bigint unsigned DEFAULT NULL,
  `transaction_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gateway` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','processing','completed','failed','cancelled','refunded') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `amount` decimal(10,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `gateway_response` json DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_transaction_id_unique` (`transaction_id`),
  KEY `payments_payment_method_id_foreign` (`payment_method_id`),
  KEY `payments_order_id_status_index` (`order_id`,`status`),
  KEY `payments_order_id_index` (`order_id`),
  KEY `payments_transaction_id_index` (`transaction_id`),
  KEY `payments_status_index` (`status`),
  CONSTRAINT `payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_payment_method_id_foreign` FOREIGN KEY (`payment_method_id`) REFERENCES `payment_methods` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_alerts`
--

DROP TABLE IF EXISTS `price_alerts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_alerts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `target_price` decimal(10,2) NOT NULL,
  `current_price` decimal(10,2) DEFAULT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `repeat_alert` tinyint(1) NOT NULL DEFAULT '0',
  `last_checked_at` timestamp NULL DEFAULT NULL,
  `last_triggered_at` timestamp NULL DEFAULT NULL,
  `trigger_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `price_alerts_user_id_is_active_index` (`user_id`,`is_active`),
  KEY `price_alerts_product_id_is_active_index` (`product_id`,`is_active`),
  KEY `price_alerts_target_price_index` (`target_price`),
  CONSTRAINT `price_alerts_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `price_alerts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_alerts`
--

LOCK TABLES `price_alerts` WRITE;
/*!40000 ALTER TABLE `price_alerts` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_alerts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_histories`
--

DROP TABLE IF EXISTS `price_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_histories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `effective_date` timestamp NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `price_histories_product_id_foreign` (`product_id`),
  CONSTRAINT `price_histories_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_histories`
--

LOCK TABLES `price_histories` WRITE;
/*!40000 ALTER TABLE `price_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_histories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_offers`
--

DROP TABLE IF EXISTS `price_offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_offers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `product_sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `store_id` bigint unsigned NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'USD',
  `product_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `affiliate_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_stock` tinyint(1) NOT NULL DEFAULT '1',
  `stock_quantity` int DEFAULT NULL,
  `condition` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'new',
  `rating` decimal(3,1) DEFAULT NULL,
  `reviews_count` int NOT NULL DEFAULT '0',
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `specifications` json DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT '1',
  `original_price` decimal(8,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `price_offers_product_id_foreign` (`product_id`),
  KEY `price_offers_store_id_foreign` (`store_id`),
  CONSTRAINT `price_offers_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `price_offers_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_offers`
--

LOCK TABLES `price_offers` WRITE;
/*!40000 ALTER TABLE `price_offers` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_offers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_store`
--

DROP TABLE IF EXISTS `product_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_store` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `store_id` bigint unsigned NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `currency_id` bigint unsigned DEFAULT NULL,
  `is_available` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_store_product_id_store_id_unique` (`product_id`,`store_id`),
  KEY `product_store_store_id_foreign` (`store_id`),
  KEY `product_store_currency_id_foreign` (`currency_id`),
  KEY `product_store_product_id_is_available_index` (`product_id`,`is_available`),
  CONSTRAINT `product_store_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `product_store_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `product_store_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_store`
--

LOCK TABLES `product_store` WRITE;
/*!40000 ALTER TABLE `product_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) NOT NULL DEFAULT '0.00',
  `compare_at_price` decimal(8,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `brand_id` bigint unsigned DEFAULT NULL,
  `store_id` bigint unsigned DEFAULT NULL,
  `category_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `stock_quantity` int NOT NULL DEFAULT '0',
  `currency_id` bigint unsigned DEFAULT NULL,
  `quantity` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  KEY `products_store_id_foreign` (`store_id`),
  KEY `products_name_index` (`name`),
  KEY `products_slug_index` (`slug`),
  KEY `products_category_id_index` (`category_id`),
  KEY `products_brand_id_index` (`brand_id`),
  KEY `products_price_index` (`price`),
  KEY `products_created_at_index` (`created_at`),
  KEY `products_currency_id_foreign` (`currency_id`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE SET NULL,
  CONSTRAINT `products_store_id_foreign` FOREIGN KEY (`store_id`) REFERENCES `stores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rating` tinyint unsigned NOT NULL COMMENT 'Rating from 1 to 5',
  `is_verified_purchase` tinyint(1) NOT NULL DEFAULT '0',
  `is_approved` tinyint(1) NOT NULL DEFAULT '1',
  `helpful_votes` json DEFAULT NULL COMMENT 'Array of user IDs who found this helpful',
  `helpful_count` int NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reviews_product_id_is_approved_index` (`product_id`,`is_approved`),
  KEY `reviews_user_id_created_at_index` (`user_id`,`created_at`),
  KEY `reviews_product_id_index` (`product_id`),
  KEY `reviews_user_id_index` (`user_id`),
  KEY `reviews_rating_index` (`rating`),
  KEY `reviews_product_rating_index` (`product_id`,`rating`),
  CONSTRAINT `reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rewards`
--

DROP TABLE IF EXISTS `rewards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rewards` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `points_required` int NOT NULL,
  `type` enum('discount','free_shipping','gift','cashback') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` json NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `usage_limit` int DEFAULT NULL,
  `valid_from` timestamp NULL DEFAULT NULL,
  `valid_until` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rewards_is_active_points_required_index` (`is_active`,`points_required`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rewards`
--

LOCK TABLES `rewards` WRITE;
/*!40000 ALTER TABLE `rewards` DISABLE KEYS */;
/*!40000 ALTER TABLE `rewards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stores`
--

DROP TABLE IF EXISTS `stores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `logo_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `supported_countries` json DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `priority` int NOT NULL DEFAULT '0',
  `affiliate_base_url` text COLLATE utf8mb4_unicode_ci,
  `affiliate_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_config` json DEFAULT NULL,
  `currency_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `stores_slug_unique` (`slug`),
  KEY `stores_currency_id_foreign` (`currency_id`),
  CONSTRAINT `stores_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stores`
--

LOCK TABLES `stores` WRITE;
/*!40000 ALTER TABLE `stores` DISABLE KEYS */;
/*!40000 ALTER TABLE `stores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_entries`
--

DROP TABLE IF EXISTS `telescope_entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telescope_entries` (
  `sequence` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `family_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `should_display_on_index` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`sequence`),
  UNIQUE KEY `telescope_entries_uuid_unique` (`uuid`),
  KEY `telescope_entries_batch_id_index` (`batch_id`),
  KEY `telescope_entries_family_hash_index` (`family_hash`),
  KEY `telescope_entries_created_at_index` (`created_at`),
  KEY `telescope_entries_type_should_display_on_index_index` (`type`,`should_display_on_index`)
) ENGINE=InnoDB AUTO_INCREMENT=402 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_entries`
--

LOCK TABLES `telescope_entries` WRITE;
/*!40000 ALTER TABLE `telescope_entries` DISABLE KEYS */;
INSERT INTO `telescope_entries` VALUES (1,'a01a4fbc-9ed8-4a03-8f89-64cc9d7a9876','a01a4fbc-c973-424c-b631-b5aeface3dca','c6b236da76150c72996f30401be1e8bf',1,'exception','{\"class\":\"Illuminate\\\\Database\\\\QueryException\",\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":824,\"message\":\"SQLSTATE[42000]: Syntax error or access violation: 1072 Key column \'status\' doesn\'t exist in table (Connection: mysql, SQL: alter table `users` add index `users_status_index`(`status`))\",\"context\":null,\"trace\":[{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":778},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Connection.php\",\"line\":559},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Schema\\/Blueprint.php\",\"line\":121},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Schema\\/Builder.php\",\"line\":618},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Schema\\/Builder.php\",\"line\":460},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Support\\/Facades\\/Facade.php\",\"line\":363},{\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":100},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":514},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":439},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":448},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":250},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/View\\/Components\\/Task.php\",\"line\":41},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":809},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":250},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":210},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":137},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Console\\/Migrations\\/MigrateCommand.php\",\"line\":116},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Migrations\\/Migrator.php\",\"line\":666},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Console\\/Migrations\\/MigrateCommand.php\",\"line\":109},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Database\\/Console\\/Migrations\\/MigrateCommand.php\",\"line\":88},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php\",\"line\":36},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Util.php\",\"line\":43},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php\",\"line\":96},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/BoundMethod.php\",\"line\":35},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Container\\/Container.php\",\"line\":836},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php\",\"line\":211},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Command\\/Command.php\",\"line\":318},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Console\\/Command.php\",\"line\":180},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":1110},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":359},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":194},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php\",\"line\":197},{\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35}],\"line_preview\":{\"815\":\"        \\/\\/ message to include the bindings with SQL, which will make this exception a\",\"816\":\"        \\/\\/ lot more helpful to the developer instead of just the database\'s errors.\",\"817\":\"        catch (Exception $e) {\",\"818\":\"            if ($this->isUniqueConstraintError($e)) {\",\"819\":\"                throw new UniqueConstraintViolationException(\",\"820\":\"                    $this->getName(), $query, $this->prepareBindings($bindings), $e\",\"821\":\"                );\",\"822\":\"            }\",\"823\":\"\",\"824\":\"            throw new QueryException(\",\"825\":\"                $this->getName(), $query, $this->prepareBindings($bindings), $e\",\"826\":\"            );\",\"827\":\"        }\",\"828\":\"    }\",\"829\":\"\",\"830\":\"    \\/**\",\"831\":\"     * Determine if the given database exception was caused by a unique constraint violation.\",\"832\":\"     *\",\"833\":\"     * @param  \\\\Exception  $exception\",\"834\":\"     * @return bool\"},\"hostname\":\"f8eb3521363d\",\"occurrences\":1}','2025-10-13 09:44:33'),(2,'a01a4fa1-66c0-4b48-b7c3-608a6f42dcc0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'migrations\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"78.11\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"472343cbf78736393ab995dc1735b75f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:15'),(3,'a01a4fa2-2bb2-4b7d-a990-ae3d8b08a2d7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'migrations\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.51\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"472343cbf78736393ab995dc1735b75f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:16'),(4,'a01a4fa2-574d-4a0b-a4f1-47fe5518a37f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `migrations` (`id` int unsigned not null auto_increment primary key, `migration` varchar(255) not null, `batch` int not null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"66.99\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"246242198a8fbc1beb167611385ac644\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:16'),(5,'a01a4fa2-5da1-4c57-a84c-8f7a5838d2c4','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'migrations\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"2.06\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"472343cbf78736393ab995dc1735b75f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:16'),(6,'a01a4fa2-7ef8-4b01-abfe-922c4f98ed69','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select `migration` from `migrations` order by `batch` asc, `migration` asc\",\"time\":\"9.77\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"ed08a59c7f0b8851f0fd2291ca94d5c7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:16'),(7,'a01a4fa2-8102-4b3b-9a1c-cfdc9e3b010c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select `migration` from `migrations` order by `batch` asc, `migration` asc\",\"time\":\"0.60\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"ed08a59c7f0b8851f0fd2291ca94d5c7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:16'),(8,'a01a4fa3-10b1-4399-b5b6-fdf2110b614b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select max(`batch`) as aggregate from `migrations`\",\"time\":\"0.66\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"06e60d7b3d1a0c2de504de4e6f27735e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:16'),(9,'a01a4fa3-5977-42d3-9999-41b12e6615c5','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `users` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `email` varchar(255) not null, `email_verified_at` timestamp null, `password` varchar(255) not null, `remember_token` varchar(100) null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"101.33\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000000_create_users_table.php\",\"line\":16,\"hash\":\"47c20151560e04dbf058d1eaaf31fc80\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:16'),(10,'a01a4fa3-6ce4-4890-bf74-14fa1c2a678c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add unique `users_email_unique`(`email`)\",\"time\":\"49.40\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000000_create_users_table.php\",\"line\":16,\"hash\":\"0648806a3d18c0f5b81e2257de64675e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(11,'a01a4fa3-98e9-47c8-b63d-a3c636273048','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `password_reset_tokens` (`email` varchar(255) not null, `token` varchar(255) not null, `created_at` timestamp null, primary key (`email`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"112.10\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000000_create_users_table.php\",\"line\":26,\"hash\":\"d1b8ec2d95ac0278e9c404209ef4276d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(12,'a01a4fa3-d023-40e6-adc8-187d396471fc','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `sessions` (`id` varchar(255) not null, `user_id` bigint unsigned null, `ip_address` varchar(45) null, `user_agent` text null, `payload` longtext not null, `last_activity` int not null, primary key (`id`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"122.15\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000000_create_users_table.php\",\"line\":32,\"hash\":\"644f094fd9982dc877d67d9ae8dab9a6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(13,'a01a4fa3-d811-4c95-a8a9-6054fab49879','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'0001_01_01_000000_create_users_table\', 1)\",\"time\":\"8.34\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(14,'a01a4fa3-f694-4305-b7a0-25abfca89aaa','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `cache` (`key` varchar(255) not null, `value` mediumtext not null, `expiration` int not null, primary key (`key`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"71.69\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000001_create_cache_table.php\",\"line\":16,\"hash\":\"372cda85881fe89b6a62d84e07110cf1\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(15,'a01a4fa4-1125-4824-8129-ce8ffffcf81d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `cache_locks` (`key` varchar(255) not null, `owner` varchar(255) not null, `expiration` int not null, primary key (`key`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"67.45\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000001_create_cache_table.php\",\"line\":22,\"hash\":\"3d517557cf20220e6ecfaf0a9ee12c4f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(16,'a01a4fa4-14dc-4dc0-87ba-00430ae0ee50','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'0001_01_01_000001_create_cache_table\', 1)\",\"time\":\"8.33\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(17,'a01a4fa4-29cf-4f20-a228-5d1ae8a6c682','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `jobs` (`id` bigint unsigned not null auto_increment primary key, `queue` varchar(255) not null, `payload` longtext not null, `attempts` tinyint unsigned not null, `reserved_at` int unsigned null, `available_at` int unsigned not null, `created_at` int unsigned not null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"44.93\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000002_create_jobs_table.php\",\"line\":16,\"hash\":\"87d7e48163c279f619932f5e34922b35\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(18,'a01a4fa4-385c-45f0-a166-a56a1e34d1dc','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `jobs` add index `jobs_queue_index`(`queue`)\",\"time\":\"36.85\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000002_create_jobs_table.php\",\"line\":16,\"hash\":\"0cfaf07533bec3024be637314b74804b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(19,'a01a4fa4-48d2-4ce9-ba4d-653a53b1d30a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `job_batches` (`id` varchar(255) not null, `name` varchar(255) not null, `total_jobs` int not null, `pending_jobs` int not null, `failed_jobs` int not null, `failed_job_ids` longtext not null, `options` mediumtext null, `cancelled_at` int null, `created_at` int not null, `finished_at` int null, primary key (`id`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"41.51\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000002_create_jobs_table.php\",\"line\":26,\"hash\":\"cce8d09300a9a72f6d316f46dce3ac3f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(20,'a01a4fa4-63a5-4f1c-a373-bc19bf2e5664','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `failed_jobs` (`id` bigint unsigned not null auto_increment primary key, `uuid` varchar(255) not null, `connection` text not null, `queue` text not null, `payload` longtext not null, `exception` longtext not null, `failed_at` timestamp not null default CURRENT_TIMESTAMP) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"41.03\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000002_create_jobs_table.php\",\"line\":39,\"hash\":\"2036eec2d3e24057db38a9579d6633e3\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(21,'a01a4fa4-909f-4d3d-864e-6334ac6807f7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `failed_jobs` add unique `failed_jobs_uuid_unique`(`uuid`)\",\"time\":\"114.76\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/0001_01_01_000002_create_jobs_table.php\",\"line\":39,\"hash\":\"f851653a45d1f2394473d70db5636fd3\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(22,'a01a4fa4-9471-47d8-a337-1837dd44d5bc','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'0001_01_01_000002_create_jobs_table\', 1)\",\"time\":\"8.57\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(23,'a01a4fa4-aa1a-4379-a2c8-7e33aac7ae32','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `telescope_entries` (`sequence` bigint unsigned not null auto_increment primary key, `uuid` char(36) not null, `batch_id` char(36) not null, `family_hash` varchar(255) null, `should_display_on_index` tinyint(1) not null default \'1\', `type` varchar(20) not null, `content` longtext not null, `created_at` datetime null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"46.70\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":38,\"hash\":\"d9429550f8856c1af1c89f24a6440cb5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(24,'a01a4fa4-b6ba-49ad-bc83-e3c9f1056473','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add unique `telescope_entries_uuid_unique`(`uuid`)\",\"time\":\"32.00\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":38,\"hash\":\"9fb859ae1faff74c6b9e0b70dfd8eea9\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(25,'a01a4fa4-c3fa-4aa0-95a9-13cc329324a0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add index `telescope_entries_batch_id_index`(`batch_id`)\",\"time\":\"33.48\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":38,\"hash\":\"2b075509a9242d6e3f622536c5ccca07\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(26,'a01a4fa4-d1a5-4de5-a359-0fbddab8f143','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add index `telescope_entries_family_hash_index`(`family_hash`)\",\"time\":\"34.61\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":38,\"hash\":\"3d25a2a244bd2028dfa0326d3dbf7f4c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(27,'a01a4fa4-dce4-4b6a-9c73-19e6643be097','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add index `telescope_entries_created_at_index`(`created_at`)\",\"time\":\"28.51\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":38,\"hash\":\"7352e7f84460fb7ffc450e7ea4de9dc7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:17'),(28,'a01a4fa4-ea4f-4336-82c7-52c4fefa16ff','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries` add index `telescope_entries_type_should_display_on_index_index`(`type`, `should_display_on_index`)\",\"time\":\"33.92\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":38,\"hash\":\"7317a4cad2dfa1a5167548a6acd0b6a5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(29,'a01a4fa5-0673-47fc-b691-2d99181cedc7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `telescope_entries_tags` (`entry_uuid` char(36) not null, `tag` varchar(255) not null, primary key (`entry_uuid`, `tag`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"59.95\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":55,\"hash\":\"f8c7e1e3c3d557b70e7a918609f839f2\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(30,'a01a4fa5-1692-4e0e-b445-8fbf8237e509','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries_tags` add index `telescope_entries_tags_tag_index`(`tag`)\",\"time\":\"40.91\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":55,\"hash\":\"0bdb35d17e876d6225a7774a2c17647d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(31,'a01a4fa5-41eb-4c03-b0f4-e90e0aa603f7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `telescope_entries_tags` add constraint `telescope_entries_tags_entry_uuid_foreign` foreign key (`entry_uuid`) references `telescope_entries` (`uuid`) on delete cascade\",\"time\":\"110.65\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":55,\"hash\":\"662a818f80a3a9ba2570081fd7a6af2f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(32,'a01a4fa5-5686-4f3f-a5d1-aab0d9d5affa','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `telescope_monitoring` (`tag` varchar(255) not null, primary key (`tag`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"52.30\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2018_08_08_100000_create_telescope_entries_table.php\",\"line\":68,\"hash\":\"18d1fa09eade84a80848982d91caec5c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(33,'a01a4fa5-5976-4157-a243-c2b2ba9bafad','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2018_08_08_100000_create_telescope_entries_table\', 1)\",\"time\":\"6.69\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(34,'a01a4fa5-7414-48b8-8c60-33c3bbb8e852','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `personal_access_tokens` (`id` bigint unsigned not null auto_increment primary key, `tokenable_type` varchar(255) not null, `tokenable_id` bigint unsigned not null, `name` text not null, `token` varchar(64) not null, `abilities` text null, `last_used_at` timestamp null, `expires_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"61.43\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2019_12_14_000001_create_personal_access_tokens_table.php\",\"line\":16,\"hash\":\"4a0ff1f9426f4a722da500373caba30c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(35,'a01a4fa5-807e-426a-9d1b-dd900b441c4a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `personal_access_tokens` add index `personal_access_tokens_tokenable_type_tokenable_id_index`(`tokenable_type`, `tokenable_id`)\",\"time\":\"31.42\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2019_12_14_000001_create_personal_access_tokens_table.php\",\"line\":16,\"hash\":\"23e16d13faedc7fd756b258a984d3cad\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(36,'a01a4fa5-8bd6-42b5-b242-0e4988150479','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `personal_access_tokens` add unique `personal_access_tokens_token_unique`(`token`)\",\"time\":\"28.57\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2019_12_14_000001_create_personal_access_tokens_table.php\",\"line\":16,\"hash\":\"6d0025967d6eebfcb6fddf6dcb6ed14c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(37,'a01a4fa5-984f-4e82-89a1-5c74a28eb12b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `personal_access_tokens` add index `personal_access_tokens_expires_at_index`(`expires_at`)\",\"time\":\"31.56\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2019_12_14_000001_create_personal_access_tokens_table.php\",\"line\":16,\"hash\":\"6792178b8d542b1217f7bb7a0c7a024c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(38,'a01a4fa5-9b6e-4d6f-923d-1457be12d8d8','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2019_12_14_000001_create_personal_access_tokens_table\', 1)\",\"time\":\"7.22\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(39,'a01a4fa5-c0d7-41ee-b6c3-37b275ff5d54','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `password_confirmed_at` timestamp null after `password`\",\"time\":\"91.31\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_09_27_000000_add_password_confirmed_at_to_users_table.php\",\"line\":16,\"hash\":\"c83e3a558ece7f9cbcd043a49fc52e91\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(40,'a01a4fa5-c44e-4506-8699-9cc9e55293f2','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2024_09_27_000000_add_password_confirmed_at_to_users_table\', 1)\",\"time\":\"8.09\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(41,'a01a4fa5-e1f2-49b3-a4db-e8fe5c83e7b2','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `analytics_events` (`id` bigint unsigned not null auto_increment primary key, `event_type` varchar(50) not null, `event_name` varchar(100) not null, `user_id` bigint unsigned null, `product_id` bigint unsigned null, `category_id` bigint unsigned null, `store_id` bigint unsigned null, `metadata` json null, `ip_address` varchar(45) null, `user_agent` varchar(255) null, `session_id` varchar(100) null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"68.38\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_10_01_000002_create_analytics_events_table.php\",\"line\":16,\"hash\":\"be99a7e8c1229a2ee8c2251cc3b984af\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(42,'a01a4fa6-0dcb-48f8-88d1-24384caab0d0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `analytics_events` add constraint `analytics_events_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"111.93\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_10_01_000002_create_analytics_events_table.php\",\"line\":16,\"hash\":\"76f510fc63cb3882de44ee6c5ab9b44e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(43,'a01a4fa6-1a5f-4916-a159-209b36e46b3b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `analytics_events` add index `analytics_events_event_type_created_at_index`(`event_type`, `created_at`)\",\"time\":\"31.75\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_10_01_000002_create_analytics_events_table.php\",\"line\":16,\"hash\":\"9b139f4e1f679b180950b063c06b2b43\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(44,'a01a4fa6-2be5-40e7-8802-bea519bb3084','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `analytics_events` add index `analytics_events_user_id_created_at_index`(`user_id`, `created_at`)\",\"time\":\"44.58\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_10_01_000002_create_analytics_events_table.php\",\"line\":16,\"hash\":\"ef24ea158b0ef0936570e74ba8ce4ecb\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(45,'a01a4fa6-3595-4a5b-a180-5ef03b11cd09','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `analytics_events` add index `analytics_events_product_id_created_at_index`(`product_id`, `created_at`)\",\"time\":\"24.50\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_10_01_000002_create_analytics_events_table.php\",\"line\":16,\"hash\":\"17fa6c5a8fe1920a4db1704da2b94e53\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(46,'a01a4fa6-4301-413f-9e3e-e33224e6b77d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `analytics_events` add index `analytics_events_created_at_index`(`created_at`)\",\"time\":\"33.99\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_10_01_000002_create_analytics_events_table.php\",\"line\":16,\"hash\":\"6e9e8556a99de6abdb415f5996248a19\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(47,'a01a4fa6-53fa-4a06-aa38-1d0a6c72d4a9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `analytics_events` add index `analytics_events_event_type_index`(`event_type`)\",\"time\":\"43.16\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_10_01_000002_create_analytics_events_table.php\",\"line\":16,\"hash\":\"bc350c5b9e3255dfc50c933e5e1ddec1\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(48,'a01a4fa6-62a9-4c26-b6c2-43bc17e7c07e','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `analytics_events` add index `analytics_events_session_id_index`(`session_id`)\",\"time\":\"37.28\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2024_10_01_000002_create_analytics_events_table.php\",\"line\":16,\"hash\":\"8033785d31590704843c543619edc352\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(49,'a01a4fa6-65fa-4b6d-9b90-812535c7b7b9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2024_10_01_000002_create_analytics_events_table\', 1)\",\"time\":\"7.55\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(50,'a01a4fa6-6922-4e4b-8f8c-0d9674486f3b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'users\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.47\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":16,\"hash\":\"9f3f6c7be4340aeab9da99488bbc5b61\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:18'),(51,'a01a4fa6-6aff-46d5-a716-56eb03b690f7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'users\' order by ordinal_position asc\",\"time\":\"4.18\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":19,\"hash\":\"cc0cc7e6dff5ba2255c65426c5f591e9\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(52,'a01a4fa6-6bd9-4b64-9e9d-2be51d23e1a7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'users\' order by ordinal_position asc\",\"time\":\"1.71\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":22,\"hash\":\"cc0cc7e6dff5ba2255c65426c5f591e9\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(53,'a01a4fa6-6d0d-4741-a85b-68b5d5d27c01','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'users\' order by ordinal_position asc\",\"time\":\"2.23\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":25,\"hash\":\"cc0cc7e6dff5ba2255c65426c5f591e9\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(54,'a01a4fa6-93c3-4bfe-9dd9-038284dd5cd1','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `encrypted_phone` text null after `email_verified_at`\",\"time\":\"98.34\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":17,\"hash\":\"9931200dfacfdccd436532369c5a9d1c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(55,'a01a4fa6-b353-4ceb-8021-73845eb3831a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `encrypted_address` text null after `encrypted_phone`\",\"time\":\"80.52\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":17,\"hash\":\"14c8ec00c21acbc0b463862aca70782e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(56,'a01a4fa6-d085-48b7-be56-ca84ee04f238','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `encrypted_notes` text null after `encrypted_address`\",\"time\":\"74.35\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":17,\"hash\":\"2232f47566f7cf7bca5cf4d799a608a6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(57,'a01a4fa6-d127-4079-a727-ee8938c449a3','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'stores\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.22\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":31,\"hash\":\"e530ab024a255cf6c655e5fa97706c6f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(58,'a01a4fa6-d1ac-4948-ae0d-9bd6d04b6ad8','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'price_offers\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.09\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":52,\"hash\":\"46591c12dd6866237ab7b440bda4aaaa\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(59,'a01a4fa6-d22d-46bc-bcde-3f722b969c47','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'reviews\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.07\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000002_add_encrypted_fields.php\",\"line\":64,\"hash\":\"626f56cf1e865a285780e33012a812e5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(60,'a01a4fa6-d61d-4247-91c9-c67c444b1938','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_01_15_000002_add_encrypted_fields\', 1)\",\"time\":\"9.18\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(61,'a01a4fa6-eda9-4895-89d7-a308b70d6020','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `audit_logs` (`id` bigint unsigned not null auto_increment primary key, `event` varchar(255) not null, `auditable_type` varchar(255) not null, `auditable_id` bigint unsigned not null, `user_id` bigint unsigned null, `ip_address` varchar(45) null, `user_agent` varchar(255) null, `old_values` json null, `new_values` json null, `metadata` json null, `url` varchar(255) null, `method` varchar(10) null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"53.72\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000003_create_audit_logs_table.php\",\"line\":16,\"hash\":\"fecd8cf4d1a983ea489f6e12471c3d0e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(62,'a01a4fa6-fa48-49d9-b761-608655993651','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `audit_logs` add index `audit_logs_auditable_type_auditable_id_index`(`auditable_type`, `auditable_id`)\",\"time\":\"31.96\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000003_create_audit_logs_table.php\",\"line\":16,\"hash\":\"e7b85cb02897478d1c2f28ee2ec48800\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(63,'a01a4fa7-0485-467f-b422-2d42fb569f86','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `audit_logs` add index `audit_logs_user_id_index`(`user_id`)\",\"time\":\"25.93\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000003_create_audit_logs_table.php\",\"line\":16,\"hash\":\"3874feae5422fe9a1dde0b80c43da46f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(64,'a01a4fa7-0f03-41e5-beeb-df76675af542','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `audit_logs` add index `audit_logs_event_index`(`event`)\",\"time\":\"26.50\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000003_create_audit_logs_table.php\",\"line\":16,\"hash\":\"ff812897dde73b893314262362a7861f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(65,'a01a4fa7-1a24-4f01-98a5-d53d4eed686f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `audit_logs` add index `audit_logs_created_at_index`(`created_at`)\",\"time\":\"28.16\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000003_create_audit_logs_table.php\",\"line\":16,\"hash\":\"828078890ffbb6964289f9012ef76a40\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(66,'a01a4fa7-2754-4555-b9d3-cad162e74687','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `audit_logs` add index `audit_logs_event_created_at_index`(`event`, `created_at`)\",\"time\":\"33.48\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000003_create_audit_logs_table.php\",\"line\":16,\"hash\":\"99383625ac97cc64f23a03287ae422a5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(67,'a01a4fa7-3556-4099-9ae7-1e542d47f20d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `audit_logs` add index `audit_logs_ip_address_index`(`ip_address`)\",\"time\":\"35.53\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000003_create_audit_logs_table.php\",\"line\":16,\"hash\":\"945902871275ece18e6c9c306af008d7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(68,'a01a4fa7-38b8-4850-9aa6-5fbaa9b6d38b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_01_15_000003_create_audit_logs_table\', 1)\",\"time\":\"7.75\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(69,'a01a4fa7-3bff-4f3c-a083-10391567185e','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'notifications\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.64\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000004_create_notifications_table.php\",\"line\":16,\"hash\":\"ad768e681c40409b9c8fa4db3d841f2a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(70,'a01a4fa7-5080-4843-984a-dd5385430373','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `notifications` (`id` char(36) not null, `type` varchar(255) not null, `notifiable_type` varchar(255) not null, `notifiable_id` bigint unsigned not null, `data` text not null, `read_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null, primary key (`id`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"51.78\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000004_create_notifications_table.php\",\"line\":17,\"hash\":\"5f09c3852f0d724efd406ea8a50a35a6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(71,'a01a4fa7-5cb2-45e2-9a2a-7fff8a81c491','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `notifications` add index `notifications_notifiable_type_notifiable_id_index`(`notifiable_type`, `notifiable_id`)\",\"time\":\"30.87\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000004_create_notifications_table.php\",\"line\":17,\"hash\":\"d1e52015ac59bba4fa86595b8177bbce\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(72,'a01a4fa7-6a97-40a8-9458-49404ce54ee0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `notifications` add index `notifications_created_at_index`(`created_at`)\",\"time\":\"35.20\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000004_create_notifications_table.php\",\"line\":17,\"hash\":\"d048188c734a2cb4cad228076d7ed3ee\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(73,'a01a4fa7-7637-462e-9be9-403fec89def3','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `notifications` add index `notifications_notifiable_type_notifiable_id_read_at_index`(`notifiable_type`, `notifiable_id`, `read_at`)\",\"time\":\"29.43\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_01_15_000004_create_notifications_table.php\",\"line\":17,\"hash\":\"43abaae9a153f73c4f3a04f600696282\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(74,'a01a4fa7-790e-471d-9646-bc1d0c43ebf1','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_01_15_000004_create_notifications_table\', 1)\",\"time\":\"6.41\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(75,'a01a4fa7-9242-427a-9690-be8f02d2c847','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `cart_items` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned not null, `product_id` bigint unsigned not null, `quantity` int unsigned not null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"56.54\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_02_01_000001_create_cart_items_table.php\",\"line\":16,\"hash\":\"fcad817aeefabeaa5856a294f63852ae\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(76,'a01a4fa7-9de0-49f8-9a18-38bb9dd1b0b0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `cart_items` add index `cart_items_user_id_index`(`user_id`)\",\"time\":\"29.31\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_02_01_000001_create_cart_items_table.php\",\"line\":16,\"hash\":\"4d11211725ebab9af7138abbe8a5a079\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(77,'a01a4fa7-aa81-4f02-b5d3-39b9d193f846','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `cart_items` add index `cart_items_product_id_index`(`product_id`)\",\"time\":\"31.99\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_02_01_000001_create_cart_items_table.php\",\"line\":16,\"hash\":\"0b3e0110de1e966af5e12d1a1d1eb4a3\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(78,'a01a4fa7-adab-48fb-b9a0-461220e87cf9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_02_01_000001_create_cart_items_table\', 1)\",\"time\":\"7.00\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(79,'a01a4fa7-b0d7-4792-80dd-7587c437941e','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'notifications\' order by ordinal_position asc\",\"time\":\"1.98\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_02_01_000002_alter_notifications_add_user_id.php\",\"line\":14,\"hash\":\"38f3871a0dfb48aa39ad0a0637200e54\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(80,'a01a4fa7-e2c2-4518-898f-b1f9643b4157','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `notifications` add `user_id` bigint unsigned null\",\"time\":\"127.29\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_02_01_000002_alter_notifications_add_user_id.php\",\"line\":13,\"hash\":\"0ac537468af0d3c72a103e33d9c549b2\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(81,'a01a4fa7-ef4c-48a2-adec-01860e6540e7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `notifications` add index `notifications_user_id_index`(`user_id`)\",\"time\":\"31.81\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_02_01_000002_alter_notifications_add_user_id.php\",\"line\":13,\"hash\":\"f97339fe8b1edbfc8f801ee4a079bbcd\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:19'),(82,'a01a4fa7-f1bb-4e49-b6c9-bf4eaa9265c8','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_02_01_000002_alter_notifications_add_user_id\', 1)\",\"time\":\"5.42\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(83,'a01a4fa8-11bd-4360-9daa-3df3e8ad0d40','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `brands` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `slug` varchar(255) not null, `description` text null, `logo_url` varchar(255) null, `website_url` varchar(255) null, `is_active` tinyint(1) not null default \'1\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"74.72\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145450_create_brands_table.php\",\"line\":16,\"hash\":\"a84664c8ccc5287d82991196da4f12c8\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(84,'a01a4fa8-206c-4f46-8971-1101e7931559','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `brands` add unique `brands_slug_unique`(`slug`)\",\"time\":\"37.18\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145450_create_brands_table.php\",\"line\":16,\"hash\":\"5e7beaecb94e6ba964207587ed603675\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(85,'a01a4fa8-2421-40c5-9183-39c12c576de4','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_18_145450_create_brands_table\', 1)\",\"time\":\"8.26\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(86,'a01a4fa8-6b93-43cb-8f6c-521b842724bd','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `categories` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `slug` varchar(255) not null, `parent_id` bigint unsigned null, `level` int not null default \'1\', `description` text null, `image_url` varchar(255) null, `is_active` tinyint(1) not null default \'1\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"173.46\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145451_create_categories_table.php\",\"line\":16,\"hash\":\"1b9f7793817cfc9b29441aa84cad7e94\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(87,'a01a4fa8-a87c-43ea-a7e4-a3b775e3cbab','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `categories` add constraint `categories_parent_id_foreign` foreign key (`parent_id`) references `categories` (`id`) on delete cascade\",\"time\":\"155.54\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145451_create_categories_table.php\",\"line\":16,\"hash\":\"4ccd04b5322d6536aa53f3c1d80ed757\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(88,'a01a4fa8-b3d4-4a4d-acb8-395e4e5626d5','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `categories` add unique `categories_slug_unique`(`slug`)\",\"time\":\"28.68\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145451_create_categories_table.php\",\"line\":16,\"hash\":\"f707a9b64585b2a3e2aae1e0d8517941\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(89,'a01a4fa8-b758-47bf-93a2-e7a47fe89b14','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_18_145451_create_categories_table\', 1)\",\"time\":\"7.96\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(90,'a01a4fa8-cd9c-4b7f-a68c-66d672322e39','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `products` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `slug` varchar(255) not null, `description` text null, `price` decimal(8, 2) not null default \'0\', `compare_at_price` decimal(8, 2) null, `is_active` tinyint(1) not null default \'1\', `brand_id` bigint unsigned null, `category_id` bigint unsigned null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"49.66\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145452_create_products_table.php\",\"line\":13,\"hash\":\"de9fe4dfcfcd53523d2050ecb7020b5e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(91,'a01a4fa8-fbe7-48f1-aa0f-97870e1a1b75','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add constraint `products_brand_id_foreign` foreign key (`brand_id`) references `brands` (`id`) on delete set null\",\"time\":\"118.23\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145452_create_products_table.php\",\"line\":13,\"hash\":\"9926cd747fbf41cb777f6da5beea3f1b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(92,'a01a4fa9-2ba5-46fb-bc83-c1d2172fe5a6','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add constraint `products_category_id_foreign` foreign key (`category_id`) references `categories` (`id`) on delete set null\",\"time\":\"121.89\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145452_create_products_table.php\",\"line\":13,\"hash\":\"2f500fec0992eb6653f7a052814dbd09\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(93,'a01a4fa9-35f6-42e9-b939-628695157298','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add unique `products_slug_unique`(`slug`)\",\"time\":\"26.11\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145452_create_products_table.php\",\"line\":13,\"hash\":\"3511ff48da1cccbe35abeba69fc5a322\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(94,'a01a4fa9-38f2-4a31-8cf6-c53e38efe756','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_18_145452_create_products_table\', 1)\",\"time\":\"6.51\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(95,'a01a4fa9-5c0e-47c9-9610-1497c17c1838','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `languages` (`id` bigint unsigned not null auto_increment primary key, `code` varchar(5) not null, `name` varchar(255) not null, `native_name` varchar(255) not null, `direction` enum(\'ltr\', \'rtl\') not null default \'ltr\', `is_active` tinyint(1) not null default \'1\', `is_default` tinyint(1) not null default \'0\', `sort_order` int not null default \'0\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"83.79\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":17,\"hash\":\"b830456ec47df7749e19ff5733584dc7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(96,'a01a4fa9-7366-4c09-8099-87eabf784b81','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `languages` add unique `languages_code_unique`(`code`)\",\"time\":\"59.40\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":17,\"hash\":\"f9e10f0e2ca870ab21f2ae3c5e4999e2\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:20'),(97,'a01a4fa9-86c7-4c15-9098-1ad142000add','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `currencies` (`id` bigint unsigned not null auto_increment primary key, `code` varchar(3) not null, `name` varchar(255) not null, `symbol` varchar(10) not null, `exchange_rate` decimal(10, 4) not null default \'1\', `is_active` tinyint(1) not null default \'1\', `is_default` tinyint(1) not null default \'0\', `sort_order` int not null default \'0\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"48.95\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":33,\"hash\":\"f327520487d8e5e4be1bc2b82359f003\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:21'),(98,'a01a4fa9-94bc-4564-b710-fa01542ce939','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `currencies` add unique `currencies_code_unique`(`code`)\",\"time\":\"35.37\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":33,\"hash\":\"880e9a73713ff15bbc6133be9e25f255\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:21'),(99,'a01a4faa-17be-441d-be28-e72013158049','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `language_currency` (`id` bigint unsigned not null auto_increment primary key, `language_id` bigint unsigned not null, `currency_id` bigint unsigned not null, `is_default` tinyint(1) not null default \'0\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"149.11\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":49,\"hash\":\"e3675cc04e37b6e47611f085551f65b6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:21'),(100,'a01a4faa-5984-4650-b3f0-495e8a6ff38c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `language_currency` add constraint `language_currency_language_id_foreign` foreign key (`language_id`) references `languages` (`id`) on delete cascade\",\"time\":\"168.09\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":49,\"hash\":\"524455f5d6247aa50b9f7c6138b9f168\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:21'),(101,'a01a4faa-8d84-4d03-a5f1-76c4509887ed','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `language_currency` add constraint `language_currency_currency_id_foreign` foreign key (`currency_id`) references `currencies` (`id`) on delete cascade\",\"time\":\"132.77\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":49,\"hash\":\"d7206456cda4f19fc95a3b0bbd94077c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:21'),(102,'a01a4faa-b019-4d95-bef4-015c2c003972','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `language_currency` add unique `language_currency_language_id_currency_id_unique`(`language_id`, `currency_id`)\",\"time\":\"88.17\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":49,\"hash\":\"67dcd820be5babf382308954a7e7d31e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:21'),(103,'a01a4faa-ed4f-4662-a4f4-a0f28ffbe968','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `user_locale_settings` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned null, `session_id` varchar(255) null, `language_id` bigint unsigned not null, `currency_id` bigint unsigned not null, `ip_address` varchar(45) null, `country_code` varchar(2) null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"155.78\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":60,\"hash\":\"a220d4ea51a7deda6c0e36acf476f96a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:21'),(104,'a01a4fab-d505-4b49-85c7-873ad3fe36a5','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_locale_settings` add constraint `user_locale_settings_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"592.87\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":60,\"hash\":\"570e687b484698bbaa0c8d1a964f5d97\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:22'),(105,'a01a4fac-3690-4a15-80b1-57670fa41328','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_locale_settings` add constraint `user_locale_settings_language_id_foreign` foreign key (`language_id`) references `languages` (`id`)\",\"time\":\"249.38\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":60,\"hash\":\"1f684dcbb0fd10e7863a3c2217e9aa60\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:22'),(106,'a01a4fac-6e71-4429-a919-790e4f1c3125','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_locale_settings` add constraint `user_locale_settings_currency_id_foreign` foreign key (`currency_id`) references `currencies` (`id`)\",\"time\":\"142.69\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":60,\"hash\":\"2c0fd867ef806a5d0333bbec910ef5f9\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:22'),(107,'a01a4fac-8096-4824-811f-324a143ce581','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_locale_settings` add index `user_locale_settings_user_id_session_id_index`(`user_id`, `session_id`)\",\"time\":\"46.14\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145453_create_languages_and_currencies_tables.php\",\"line\":60,\"hash\":\"7c16fa55a6915af6ad5ed1ddd8975f36\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:22'),(108,'a01a4fac-92dd-415c-a6d5-e4f68f2d6cc8','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_18_145453_create_languages_and_currencies_tables\', 1)\",\"time\":\"7.07\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(109,'a01a4fac-b032-43b2-8bbc-ce8810f44af0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `stores` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `slug` varchar(255) not null, `logo_url` varchar(255) null, `website_url` varchar(255) null, `country_code` varchar(2) null, `supported_countries` json null, `is_active` tinyint(1) not null default \'1\', `priority` int not null default \'0\', `affiliate_base_url` text null, `affiliate_code` varchar(255) null, `api_config` json null, `currency_id` bigint unsigned null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"67.88\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145454_create_stores_table.php\",\"line\":13,\"hash\":\"732f35898905c03d2d25c8c9fc397c4b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(110,'a01a4fac-e003-4f7e-9b7c-f38c6327f3b3','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `stores` add constraint `stores_currency_id_foreign` foreign key (`currency_id`) references `currencies` (`id`) on delete cascade\",\"time\":\"122.05\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145454_create_stores_table.php\",\"line\":13,\"hash\":\"63db0c46c04fb03fb85ee8ed2d355c12\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(111,'a01a4fac-eaef-4fb2-bd94-962588fee473','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `stores` add unique `stores_slug_unique`(`slug`)\",\"time\":\"27.59\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_18_145454_create_stores_table.php\",\"line\":13,\"hash\":\"66892244fe2f6ac33e5fc13908c1749f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(112,'a01a4fac-ee13-40dd-8945-914533de7544','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_18_145454_create_stores_table\', 1)\",\"time\":\"6.94\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(113,'a01a4fad-02b6-468b-8e94-9158e5b2168b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `price_offers` (`id` bigint unsigned not null auto_increment primary key, `product_id` bigint unsigned not null, `product_sku` varchar(255) null, `store_id` bigint unsigned not null, `price` decimal(8, 2) not null, `currency` varchar(3) not null default \'USD\', `product_url` varchar(255) null, `affiliate_url` varchar(255) null, `in_stock` tinyint(1) not null default \'1\', `stock_quantity` int null, `condition` varchar(255) not null default \'new\', `rating` decimal(3, 1) null, `reviews_count` int not null default \'0\', `image_url` varchar(255) null, `specifications` json null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"46.02\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_180931_create_price_offers_table.php\",\"line\":13,\"hash\":\"33fde3b8d7a06584f10e916f415ff7a5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(114,'a01a4fad-319b-41bb-bcd4-34fe57c6307c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_offers` add constraint `price_offers_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"119.71\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_180931_create_price_offers_table.php\",\"line\":13,\"hash\":\"cafec9f94d9872befa9ec995112d55ca\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(115,'a01a4fad-5e49-48a8-9df8-0624f76ae30d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_offers` add constraint `price_offers_store_id_foreign` foreign key (`store_id`) references `stores` (`id`) on delete cascade\",\"time\":\"114.09\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_180931_create_price_offers_table.php\",\"line\":13,\"hash\":\"65908676eaad221bc19a4345de84ecfd\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(116,'a01a4fad-60f7-44a4-a391-a1cff47dbdff','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_21_180931_create_price_offers_table\', 1)\",\"time\":\"5.93\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(117,'a01a4fad-75df-4c73-8830-6a4885a41ef4','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `reviews` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned not null, `product_id` bigint unsigned not null, `title` varchar(255) null, `content` text not null, `rating` tinyint unsigned not null comment \'Rating from 1 to 5\', `is_verified_purchase` tinyint(1) not null default \'0\', `is_approved` tinyint(1) not null default \'1\', `helpful_votes` json null comment \'Array of user IDs who found this helpful\', `helpful_count` int not null default \'0\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"46.39\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184616_create_reviews_table.php\",\"line\":16,\"hash\":\"55abfe04068f1abbe22651d0ddabefb7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(118,'a01a4fad-a596-448b-9974-c618e4723120','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `reviews` add constraint `reviews_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"121.82\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184616_create_reviews_table.php\",\"line\":16,\"hash\":\"e1de6f69a4ccabfc2f37cf6c4a98d375\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(119,'a01a4fad-d5eb-46c6-9c7e-58190c805984','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `reviews` add constraint `reviews_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"123.42\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184616_create_reviews_table.php\",\"line\":16,\"hash\":\"f676b338aefb7798d02939f7c00374c6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(120,'a01a4fad-f056-416a-b2c6-5f77e9c0ffa0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `reviews` add index `reviews_product_id_is_approved_index`(`product_id`, `is_approved`)\",\"time\":\"67.32\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184616_create_reviews_table.php\",\"line\":16,\"hash\":\"2bdafb4f378e6ddb6f37ac1a00be0561\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:23'),(121,'a01a4fae-0af8-46a0-b753-550f2096ce9a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `reviews` add index `reviews_user_id_created_at_index`(`user_id`, `created_at`)\",\"time\":\"67.83\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184616_create_reviews_table.php\",\"line\":16,\"hash\":\"cb1863dca0294d05c2a314588e8593cd\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(122,'a01a4fae-14cc-4546-9929-312f582e66a8','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_21_184616_create_reviews_table\', 1)\",\"time\":\"23.96\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(123,'a01a4fae-3632-471f-925f-c305cad82d7b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `wishlists` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned not null, `product_id` bigint unsigned not null, `notes` text null, `created_at` timestamp null, `updated_at` timestamp null, `deleted_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"75.58\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184634_create_wishlists_table.php\",\"line\":16,\"hash\":\"5a79aa2076fffd3d190af8a1af8bea40\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(124,'a01a4fae-7ce6-4326-a63e-1a8fc0a96cc9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `wishlists` add constraint `wishlists_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"180.70\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184634_create_wishlists_table.php\",\"line\":16,\"hash\":\"54e6c180e9e46522ee683f3dda5049be\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(125,'a01a4fae-ad24-4281-b59d-2859a321c50c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `wishlists` add constraint `wishlists_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"123.13\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184634_create_wishlists_table.php\",\"line\":16,\"hash\":\"2eeb6769c47bfbd84bcb2a045b3b3025\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(126,'a01a4fae-bb33-4d6e-b14d-0d2d29e31258','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `wishlists` add unique `wishlists_user_id_product_id_unique`(`user_id`, `product_id`)\",\"time\":\"35.58\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184634_create_wishlists_table.php\",\"line\":16,\"hash\":\"2076fcea69a2cd89da4f390b12c4f4c2\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(127,'a01a4fae-be23-44e8-bfff-2509092e3881','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_21_184634_create_wishlists_table\', 1)\",\"time\":\"6.54\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(128,'a01a4fae-d89b-4e92-8343-6d83a12f8e18','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `price_alerts` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned not null, `product_id` bigint unsigned not null, `target_price` decimal(10, 2) not null, `current_price` decimal(10, 2) null, `currency` varchar(3) not null default \'USD\', `is_active` tinyint(1) not null default \'1\', `repeat_alert` tinyint(1) not null default \'0\', `last_checked_at` timestamp null, `last_triggered_at` timestamp null, `trigger_count` int not null default \'0\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"60.42\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184657_create_price_alerts_table.php\",\"line\":16,\"hash\":\"4d60ababd42a3a600f73c9533b69723a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(129,'a01a4fae-ff57-40b2-b415-aa0bbbd609b6','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_alerts` add constraint `price_alerts_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"98.83\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184657_create_price_alerts_table.php\",\"line\":16,\"hash\":\"7eee47963de7060e32d7c515613a6b02\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(130,'a01a4faf-3cb5-4ee3-bdf2-b6f7829b20b9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_alerts` add constraint `price_alerts_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"156.81\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184657_create_price_alerts_table.php\",\"line\":16,\"hash\":\"849eb89c7851dba0d112f7e6dee1418e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(131,'a01a4faf-4a3b-48da-9ece-0e1029501957','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_alerts` add index `price_alerts_user_id_is_active_index`(`user_id`, `is_active`)\",\"time\":\"34.22\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184657_create_price_alerts_table.php\",\"line\":16,\"hash\":\"8f91584308ad942b63b6f05a5c0e9c32\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(132,'a01a4faf-578e-42c0-a762-4c20abbf222d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_alerts` add index `price_alerts_product_id_is_active_index`(`product_id`, `is_active`)\",\"time\":\"33.80\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184657_create_price_alerts_table.php\",\"line\":16,\"hash\":\"c787d0065f0c20f6e78f40d7371b267a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(133,'a01a4faf-61d7-470c-8434-ed41679871b9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_alerts` add index `price_alerts_target_price_index`(`target_price`)\",\"time\":\"25.95\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_08_21_184657_create_price_alerts_table.php\",\"line\":16,\"hash\":\"18499b165494573e6bb101ef77ad4474\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(134,'a01a4faf-65db-49ef-b743-d7b55b3e3c38','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_08_21_184657_create_price_alerts_table\', 1)\",\"time\":\"9.23\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:24'),(135,'a01a4faf-a441-41ac-bbcb-6b380d105282','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add `image` varchar(255) null after `description`\",\"time\":\"152.59\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_07_055316_add_image_to_products_table.php\",\"line\":16,\"hash\":\"a840f2459a73878a6eb39c639abb1a0e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(136,'a01a4faf-a7dd-40e8-a8ff-5ffdc921451c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_07_055316_add_image_to_products_table\', 1)\",\"time\":\"8.32\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(137,'a01a4faf-d38e-45ba-9104-3375235102bf','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `is_admin` tinyint(1) not null default \'0\' after `email_verified_at`\",\"time\":\"105.27\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_07_073043_add_is_admin_to_users_table.php\",\"line\":16,\"hash\":\"57434924034a989bc318d2aa69466475\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(138,'a01a4faf-d7ab-437f-8d75-8d66a753257d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_07_073043_add_is_admin_to_users_table\', 1)\",\"time\":\"9.48\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(139,'a01a4fb0-102b-495a-9eab-0a813ca81da9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `role` varchar(255) not null default \'user\' after `email_verified_at`\",\"time\":\"135.77\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_000000_add_role_to_users_table.php\",\"line\":16,\"hash\":\"dc729e40dd2844a85248d33895d3b18e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(140,'a01a4fb0-1367-42ca-aa04-86b09e600344','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_000000_add_role_to_users_table\', 1)\",\"time\":\"7.28\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(141,'a01a4fb0-3d7c-47ce-8c6f-d93505cc6c7b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `brands` add `deleted_at` timestamp null\",\"time\":\"100.01\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_025634_add_soft_deletes_to_brands_table.php\",\"line\":16,\"hash\":\"cb050d218525187867f1965ba89aaf0b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(142,'a01a4fb0-40fd-47c5-81fc-1f06c989ecb0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_025634_add_soft_deletes_to_brands_table\', 1)\",\"time\":\"8.18\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(143,'a01a4fb0-683d-4bb4-bf30-cacad71c489a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `categories` add `deleted_at` timestamp null\",\"time\":\"93.85\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_025841_add_soft_deletes_to_categories_table.php\",\"line\":16,\"hash\":\"7815a03c0221fee693cb6cf8aaaf2a5d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(144,'a01a4fb0-6b79-4349-abea-02628792ea0a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_025841_add_soft_deletes_to_categories_table\', 1)\",\"time\":\"7.54\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(145,'a01a4fb0-90ce-4f02-82ad-9f4008ce7894','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `stores` add `deleted_at` timestamp null\",\"time\":\"89.25\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_030119_add_soft_deletes_to_stores_table.php\",\"line\":16,\"hash\":\"3007f1d6559e7848b5397cfdfe6adefc\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(146,'a01a4fb0-941b-45ba-9a71-6b691dd5571b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_030119_add_soft_deletes_to_stores_table\', 1)\",\"time\":\"7.63\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(147,'a01a4fb0-bfa6-46a1-8410-4f3dd051d2cb','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `stores` add `description` text null after `slug`\",\"time\":\"103.69\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_030214_add_description_to_stores_table.php\",\"line\":16,\"hash\":\"c36f26687800aa2c8f7fc99a3b7f7824\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(148,'a01a4fb0-c33d-40b7-86d8-d612c2b3e568','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_030214_add_description_to_stores_table\', 1)\",\"time\":\"8.34\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(149,'a01a4fb0-c74b-4376-adee-514bf28b0421','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'stores\' order by ordinal_position asc\",\"time\":\"2.26\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_030254_add_logo_url_to_stores_table.php\",\"line\":16,\"hash\":\"cc12589539f76005ced750b5adcaf3c6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(150,'a01a4fb0-caa8-4289-95dc-c80c95deeea8','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_030254_add_logo_url_to_stores_table\', 1)\",\"time\":\"7.57\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(151,'a01a4fb0-ce72-4ce2-839f-3c210cfb975b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'stores\' order by ordinal_position asc\",\"time\":\"2.03\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_030441_add_affiliate_code_to_stores_table.php\",\"line\":16,\"hash\":\"cc12589539f76005ced750b5adcaf3c6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(152,'a01a4fb0-d24a-468f-b3c2-3ceeb22b9303','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_030441_add_affiliate_code_to_stores_table\', 1)\",\"time\":\"9.07\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(153,'a01a4fb0-fdd7-49f0-b2fc-e5c5c69732d7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add `store_id` bigint unsigned null after `brand_id`\",\"time\":\"103.27\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_030534_add_store_id_to_products_table.php\",\"line\":16,\"hash\":\"014c4fb0576d8f3859cc097106b1e0e3\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:25'),(154,'a01a4fb1-3f9d-497e-bf55-2729676422eb','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add constraint `products_store_id_foreign` foreign key (`store_id`) references `stores` (`id`) on delete set null\",\"time\":\"167.82\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_030534_add_store_id_to_products_table.php\",\"line\":16,\"hash\":\"4196f6da0bb4dcdbdad470859c3362df\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(155,'a01a4fb1-42a7-41ce-b4f7-988e1274322f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_030534_add_store_id_to_products_table\', 1)\",\"time\":\"6.69\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(156,'a01a4fb1-78f3-4bba-a374-e21bb0df7e4a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_alerts` add `deleted_at` timestamp null\",\"time\":\"133.66\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_030823_add_soft_deletes_to_price_alerts_table.php\",\"line\":16,\"hash\":\"a61574a4e393f2bc627eeebb07c8e567\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(157,'a01a4fb1-7bf1-4147-b047-206c5a523154','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_030823_add_soft_deletes_to_price_alerts_table\', 1)\",\"time\":\"6.89\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(158,'a01a4fb1-b4a3-4565-964d-a462154f19cc','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add `deleted_at` timestamp null\",\"time\":\"138.63\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_041809_add_soft_deletes_to_products_table.php\",\"line\":16,\"hash\":\"d563d7774bd5850e4f4336ba808b3f19\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(159,'a01a4fb1-b84b-4c19-9193-977a344a75ea','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_041809_add_soft_deletes_to_products_table\', 1)\",\"time\":\"8.48\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(160,'a01a4fb1-e3ca-4388-974e-4ed1cdab64af','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `currencies` add `decimal_places` int not null default \'2\' after `exchange_rate`\",\"time\":\"104.50\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_042807_add_decimal_places_to_currencies_table.php\",\"line\":16,\"hash\":\"caacd295955371ae1b6756f801cfb718\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(161,'a01a4fb1-e6d7-424c-813b-329d1df9d624','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_042807_add_decimal_places_to_currencies_table\', 1)\",\"time\":\"7.17\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(162,'a01a4fb2-1322-43c2-ba24-eb6bc7b4c827','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_offers` add `is_available` tinyint(1) not null default \'1\'\",\"time\":\"106.71\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_064338_add_is_available_and_original_price_to_price_offers_table.php\",\"line\":16,\"hash\":\"29efe45705d8451817c51f136323691e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(163,'a01a4fb2-4321-4585-bffc-f7cf656d7592','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_offers` add `original_price` decimal(8, 2) null\",\"time\":\"122.52\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_08_064338_add_is_available_and_original_price_to_price_offers_table.php\",\"line\":16,\"hash\":\"291860aa70db21ce68dff658327d45a6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(164,'a01a4fb2-4613-4001-b523-dcecca292b49','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_08_064338_add_is_available_and_original_price_to_price_offers_table\', 1)\",\"time\":\"6.71\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(165,'a01a4fb2-73c8-4b98-b97d-e89f0c65a13a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `is_blocked` tinyint(1) not null default \'0\'\",\"time\":\"111.15\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_10_064350_add_ban_fields_to_users_table.php\",\"line\":16,\"hash\":\"34aecdc4e9b1562e270e5f4b8248e117\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(166,'a01a4fb2-9882-4342-946b-f942e225c3f3','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `ban_reason` varchar(255) null\",\"time\":\"93.71\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_10_064350_add_ban_fields_to_users_table.php\",\"line\":16,\"hash\":\"b2e5a5a36714bb31daea6d6965aaceb9\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:26'),(167,'a01a4fb2-bea1-471d-a56f-e30e8b8f55ce','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `ban_description` text null\",\"time\":\"97.23\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_10_064350_add_ban_fields_to_users_table.php\",\"line\":16,\"hash\":\"fc44c5eab19931283b3dbdb14cc520c4\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(168,'a01a4fb2-e6cb-4711-ada8-a67c9f96ce38','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `banned_at` timestamp null\",\"time\":\"102.52\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_10_064350_add_ban_fields_to_users_table.php\",\"line\":16,\"hash\":\"1278a05d1f85f7c5b9b7fa0eee3c367f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(169,'a01a4fb3-0dfa-4af5-b99c-6e15df5d8b2f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `ban_expires_at` timestamp null\",\"time\":\"99.85\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_10_064350_add_ban_fields_to_users_table.php\",\"line\":16,\"hash\":\"ad0c0f2c3e5677dc88471c7f35644c1e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(170,'a01a4fb3-115b-4aba-a717-a7dfab8adbc5','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_10_064350_add_ban_fields_to_users_table\', 1)\",\"time\":\"7.75\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(171,'a01a4fb3-4017-4955-851c-8a659ef02fb6','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `session_id` varchar(255) null after `remember_token`\",\"time\":\"112.48\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_11_233947_add_session_id_to_users_table.php\",\"line\":16,\"hash\":\"45ae7482d8cd1507102bb62039fd3640\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(172,'a01a4fb3-4368-4164-a5f3-c04ca35e474c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_11_233947_add_session_id_to_users_table\', 1)\",\"time\":\"7.67\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(173,'a01a4fb3-5d63-4725-aa0f-a8453812b7ca','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `permissions` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `guard_name` varchar(255) not null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"58.56\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":40,\"hash\":\"eb63c3583de582a709a51b49c078ca03\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(174,'a01a4fb3-6a2c-4f6c-8dba-5f789c5d0124','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `permissions` add unique `permissions_name_guard_name_unique`(`name`, `guard_name`)\",\"time\":\"32.37\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":40,\"hash\":\"5238fb7ac2ac0c6531d371b983681d76\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(175,'a01a4fb3-80d0-4717-84c7-974f711ce730','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `roles` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `guard_name` varchar(255) not null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"57.37\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":51,\"hash\":\"c8fbd6ab203ec575e47ce2d7e4f07910\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(176,'a01a4fb3-8cfc-4db4-a1ba-664539ab585f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `roles` add unique `roles_name_guard_name_unique`(`name`, `guard_name`)\",\"time\":\"30.84\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":51,\"hash\":\"476aef0b952e50c5926ba8cdc0c9bfa6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(177,'a01a4fb3-9d60-44eb-b870-8dbf6f94c241','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `model_has_permissions` (`permission_id` bigint unsigned not null, `model_type` varchar(255) not null, `model_id` bigint unsigned not null, primary key (`permission_id`, `model_id`, `model_type`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"41.45\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":72,\"hash\":\"ec1b8cf686b6562712dee3002dd401c3\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(178,'a01a4fb3-a6ec-4a17-87f4-feed36b28e44','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `model_has_permissions` add index `model_has_permissions_model_id_model_type_index`(`model_id`, `model_type`)\",\"time\":\"24.13\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":72,\"hash\":\"799c3262f33663c6bf50078fe1c8ce02\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(179,'a01a4fb3-d477-4c46-9b2b-f995ab4b7ae4','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `model_has_permissions` add constraint `model_has_permissions_permission_id_foreign` foreign key (`permission_id`) references `permissions` (`id`) on delete cascade\",\"time\":\"116.28\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":72,\"hash\":\"2c922be382fed48d8023537e84ccdd66\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(180,'a01a4fb3-e686-44a9-8a2d-8d9917b3324b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `model_has_roles` (`role_id` bigint unsigned not null, `model_type` varchar(255) not null, `model_id` bigint unsigned not null, primary key (`role_id`, `model_id`, `model_type`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"45.69\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":102,\"hash\":\"ed1930e13e87605cce4ebc47dc397bb8\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(181,'a01a4fb3-f19e-4cde-8e0d-38fef7c5b848','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `model_has_roles` add index `model_has_roles_model_id_model_type_index`(`model_id`, `model_type`)\",\"time\":\"28.03\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":102,\"hash\":\"b5fc483eb06997eadd0a189cdb6820fd\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(182,'a01a4fb4-17e9-4914-baad-81fb6c2c4bbe','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `model_has_roles` add constraint `model_has_roles_role_id_foreign` foreign key (`role_id`) references `roles` (`id`) on delete cascade\",\"time\":\"97.72\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":102,\"hash\":\"13a9f5419fe9cfd65c84f44a9af8aebe\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:27'),(183,'a01a4fb4-26e7-41d3-8bb4-4e0b59ffdd98','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `role_has_permissions` (`permission_id` bigint unsigned not null, `role_id` bigint unsigned not null, primary key (`permission_id`, `role_id`)) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"37.85\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":133,\"hash\":\"92e8ce6598a3d32430f6a20647e75cc6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(184,'a01a4fb4-49bc-4515-8fac-0960e8a6467a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `role_has_permissions` add constraint `role_has_permissions_permission_id_foreign` foreign key (`permission_id`) references `permissions` (`id`) on delete cascade\",\"time\":\"88.84\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":133,\"hash\":\"09327a2ff7df4421191b9fdf2a1cce9e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(185,'a01a4fb4-8038-4648-bce1-4846dbcd77f1','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `role_has_permissions` add constraint `role_has_permissions_role_id_foreign` foreign key (`role_id`) references `roles` (`id`) on delete cascade\",\"time\":\"139.10\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_14_065423_create_permission_tables.php\",\"line\":133,\"hash\":\"4ad12bf8366b7b214265d1ff60544e17\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(186,'a01a4fb4-863d-4d9e-a4b2-4f7182897f08','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'redis','{\"connection\":\"cache\",\"command\":\"del coprra_cache_spatie.permission.cache\",\"time\":\"0.27\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(187,'a01a4fb4-8c68-4fe5-baa9-ac800fde6f09','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_14_065423_create_permission_tables\', 1)\",\"time\":\"6.81\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(188,'a01a4fb4-cb9b-4ff4-baf5-cf31d70800ea','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add `stock_quantity` int not null default \'0\'\",\"time\":\"154.59\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_19_033122_add_stock_quantity_to_products_table.php\",\"line\":16,\"hash\":\"56c2f0a6a77ef51ee45959e755a00a97\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(189,'a01a4fb4-cebc-49b0-9f38-2cff3b20d9df','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_19_033122_add_stock_quantity_to_products_table\', 1)\",\"time\":\"7.24\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(190,'a01a4fb4-fb82-4e74-bd6a-0ec3e1c58dc6','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `is_active` tinyint(1) not null default \'1\' after `is_admin`\",\"time\":\"107.47\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_19_033158_add_is_active_to_users_table.php\",\"line\":16,\"hash\":\"5f41f34a9c68cd3b4cf04f019b0c6307\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(191,'a01a4fb5-009b-40fc-87ef-06849fb40880','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_19_033158_add_is_active_to_users_table\', 1)\",\"time\":\"12.17\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(192,'a01a4fb5-384d-4480-9a8a-2fea5ff1db1f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add `is_featured` tinyint(1) not null default \'0\' after `is_active`\",\"time\":\"133.52\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_20_000000_add_is_featured_to_products_table.php\",\"line\":16,\"hash\":\"aeb54bfe56c1f5681756f1842d572c83\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(193,'a01a4fb5-3cef-4616-a573-f8a30dc729a7','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_20_000000_add_is_featured_to_products_table\', 1)\",\"time\":\"11.06\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(194,'a01a4fb5-3fe4-4b74-9621-5acbd9a22bc6','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'price_offers\' order by ordinal_position asc\",\"time\":\"2.08\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_21_225510_add_currency_to_price_offers_table.php\",\"line\":17,\"hash\":\"9d054865e25987b7310c91d98c93f78a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(195,'a01a4fb5-434b-4925-bba7-bff91ade5b16','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_21_225510_add_currency_to_price_offers_table\', 1)\",\"time\":\"7.75\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(196,'a01a4fb5-53e8-4068-a3bc-217a5cb29e16','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"drop table if exists `price_offers`\",\"time\":\"33.80\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_21_225619_recreate_price_offers_table.php\",\"line\":17,\"hash\":\"dd6f5d1f4dc266420339b88564bc606c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(197,'a01a4fb5-6830-4b40-aa25-099ac2cb4067','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `price_offers` (`id` bigint unsigned not null auto_increment primary key, `product_id` bigint unsigned not null, `product_sku` varchar(255) null, `store_id` bigint unsigned not null, `price` decimal(8, 2) not null, `currency` varchar(3) not null default \'USD\', `product_url` varchar(255) null, `affiliate_url` varchar(255) null, `in_stock` tinyint(1) not null default \'1\', `stock_quantity` int null, `condition` varchar(255) not null default \'new\', `rating` decimal(3, 1) null, `reviews_count` int not null default \'0\', `image_url` varchar(255) null, `specifications` json null, `is_available` tinyint(1) not null default \'1\', `original_price` decimal(8, 2) null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"51.04\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_21_225619_recreate_price_offers_table.php\",\"line\":20,\"hash\":\"e214e69ba191225ae1bd20504211e515\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(198,'a01a4fb5-97a6-465a-a01b-b86c8982edbe','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_offers` add constraint `price_offers_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"121.12\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_21_225619_recreate_price_offers_table.php\",\"line\":20,\"hash\":\"cafec9f94d9872befa9ec995112d55ca\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:28'),(199,'a01a4fb5-c6ab-4460-8220-aeca7c20f712','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_offers` add constraint `price_offers_store_id_foreign` foreign key (`store_id`) references `stores` (`id`) on delete cascade\",\"time\":\"120.01\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_21_225619_recreate_price_offers_table.php\",\"line\":20,\"hash\":\"65908676eaad221bc19a4345de84ecfd\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(200,'a01a4fb5-c9a8-4c5e-9107-f7d0f3ba3424','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_21_225619_recreate_price_offers_table\', 1)\",\"time\":\"6.52\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(201,'a01a4fb5-cca9-4d99-84b4-1f9ab4d78d1c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'custom_notifications\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.80\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":16,\"hash\":\"9fcc90c5fd0ca97fdaae880f52e336f5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(202,'a01a4fb5-e2f6-4a2a-96fc-24e072198862','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `custom_notifications` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned not null, `type` varchar(255) not null, `title` varchar(255) not null, `message` text not null, `data` json null, `read_at` timestamp null, `sent_at` timestamp null, `priority` int not null default \'2\', `channel` varchar(255) not null default \'database\', `status` varchar(255) not null default \'pending\', `metadata` json null, `tags` json null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"55.99\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"141f3eb39c5325f57450a1beab50c07e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(203,'a01a4fb6-1931-4a2f-bfda-8fb320475291','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add constraint `custom_notifications_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"138.54\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"3675ae0ae68779bf5de839c8b6d986ea\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(204,'a01a4fb6-27dc-4ca2-bea5-5a7062c98869','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_user_id_index`(`user_id`)\",\"time\":\"37.27\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"4f3cd6bc288052c3143e8dcc9eb7d419\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(205,'a01a4fb6-3356-4b15-8d7f-cca55548c62d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_type_index`(`type`)\",\"time\":\"29.09\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"c5ade7813419714e8e9c5f1fc23c4f60\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(206,'a01a4fb6-4618-44f2-a6d9-7078685ba06f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_status_index`(`status`)\",\"time\":\"47.64\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"3298cb5e6710e9a6165ff3cb412aaaa0\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(207,'a01a4fb6-51db-4725-9191-3dbe5f0e02c1','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_priority_index`(`priority`)\",\"time\":\"29.83\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"bf479fff72a238e8ae05dfb3aa09d0aa\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(208,'a01a4fb6-5fe0-407a-a294-c37728725b28','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_channel_index`(`channel`)\",\"time\":\"35.56\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"b960a9f8903ea7c3b29e826839de2748\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(209,'a01a4fb6-6c79-43fa-84cc-17fdead18a44','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_sent_at_index`(`sent_at`)\",\"time\":\"31.84\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"fe5b57caa017b70d743477b1003d96bc\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(210,'a01a4fb6-7b70-487b-9d08-5a9ae708a7df','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_created_at_index`(`created_at`)\",\"time\":\"38.00\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"1922f28c1736585660e4457d9cc0fb0e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(211,'a01a4fb6-87db-4235-9b68-e82cc19b9c93','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_user_id_read_at_index`(`user_id`, `read_at`)\",\"time\":\"31.48\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"0b9de219edc2846f44d735b96a2dcb8c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(212,'a01a4fb6-94b7-41a7-b2e4-c0f8988215b9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_user_id_status_index`(`user_id`, `status`)\",\"time\":\"32.58\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"5d3e65e0ad92da724e0b36aa1251aab3\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(213,'a01a4fb6-a2b1-4171-81f2-a4f5527a5a7e','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `custom_notifications` add index `custom_notifications_type_status_index`(`type`, `status`)\",\"time\":\"35.37\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_155133_create_custom_notifications_table.php\",\"line\":17,\"hash\":\"b9898eaa2a28c930c2cb39330a3a44e4\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(214,'a01a4fb6-a63a-4655-929d-a77a54d4aa14','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_25_155133_create_custom_notifications_table\', 1)\",\"time\":\"7.99\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(215,'a01a4fb6-bdbc-427a-bc60-349666aea6c9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `orders` (`id` bigint unsigned not null auto_increment primary key, `order_number` varchar(255) not null, `user_id` bigint unsigned not null, `status` enum(\'pending\', \'processing\', \'shipped\', \'delivered\', \'cancelled\', \'refunded\', \'completed\') not null default \'pending\', `total_amount` decimal(10, 2) not null, `subtotal` decimal(10, 2) not null, `tax_amount` decimal(10, 2) not null default \'0\', `shipping_amount` decimal(10, 2) not null default \'0\', `discount_amount` decimal(10, 2) not null default \'0\', `currency` varchar(3) not null default \'USD\', `shipping_address` json not null, `billing_address` json not null, `notes` text null, `shipped_at` timestamp null, `delivered_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"52.52\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185824_create_orders_table.php\",\"line\":13,\"hash\":\"3b35a2869a6838f14c7a8575d0bb0f25\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(216,'a01a4fb6-e94a-4fd8-bc84-573d7229e282','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add constraint `orders_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"111.21\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185824_create_orders_table.php\",\"line\":13,\"hash\":\"9aeec1a6cecb2c6b709861e2f4a7cb22\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(217,'a01a4fb6-f79d-452c-8a3c-63fa458715ba','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add index `orders_user_id_status_index`(`user_id`, `status`)\",\"time\":\"36.38\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185824_create_orders_table.php\",\"line\":13,\"hash\":\"75be5ca83cb395673db9d87130735b63\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(218,'a01a4fb7-01d6-4dbe-8abd-00e7f47661e1','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add unique `orders_order_number_unique`(`order_number`)\",\"time\":\"25.85\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185824_create_orders_table.php\",\"line\":13,\"hash\":\"7ddb5b97824ad0628dd131cd32bb6034\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(219,'a01a4fb7-04bb-4d28-ac3f-e1e36147cf7d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_25_185824_create_orders_table\', 1)\",\"time\":\"6.37\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(220,'a01a4fb7-1fc9-445b-a8de-aebd7fccff85','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `order_items` (`id` bigint unsigned not null auto_increment primary key, `order_id` bigint unsigned not null, `product_id` bigint unsigned not null, `quantity` int not null, `unit_price` decimal(10, 2) null, `total_price` decimal(10, 2) null, `price` decimal(10, 2) not null, `total` decimal(10, 2) not null, `product_details` json null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"63.16\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185845_create_order_items_table.php\",\"line\":13,\"hash\":\"be27b0fd44700613739922866a33fcf6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:29'),(221,'a01a4fb7-494e-4ef4-84ab-c58f98a8aa06','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `order_items` add constraint `order_items_order_id_foreign` foreign key (`order_id`) references `orders` (`id`) on delete cascade\",\"time\":\"105.96\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185845_create_order_items_table.php\",\"line\":13,\"hash\":\"4786731bce2d61849e5ae0ec959a92ab\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(222,'a01a4fb7-758c-4534-95d2-eaa6b879f0fa','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `order_items` add constraint `order_items_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"112.88\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185845_create_order_items_table.php\",\"line\":13,\"hash\":\"88da9be502d6df33efc8c4eddf82b161\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(223,'a01a4fb7-84a4-433d-831e-67028ae560bc','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `order_items` add index `order_items_order_id_product_id_index`(`order_id`, `product_id`)\",\"time\":\"38.20\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185845_create_order_items_table.php\",\"line\":13,\"hash\":\"57d89e50c2cc6254297a0fbc05d517ef\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(224,'a01a4fb7-879e-4780-b732-3b5e7f015222','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_25_185845_create_order_items_table\', 1)\",\"time\":\"6.66\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(225,'a01a4fb7-9ec6-4f56-b6be-79bdf3f3dcec','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `payment_methods` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `gateway` varchar(255) not null, `type` varchar(255) not null, `config` json null, `is_active` tinyint(1) not null default \'1\', `is_default` tinyint(1) not null default \'0\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"51.67\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185900_create_payment_methods_table.php\",\"line\":13,\"hash\":\"f28e2936eb935edd8d517e5506b3ec5d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(226,'a01a4fb7-ab69-4d44-8c4f-9ba3a646bcaf','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `payment_methods` add index `payment_methods_gateway_is_active_index`(`gateway`, `is_active`)\",\"time\":\"32.04\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185900_create_payment_methods_table.php\",\"line\":13,\"hash\":\"d1747139ee486eafea582fb33d54897d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(227,'a01a4fb7-adeb-43ef-a1ec-016bf702cc1b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_25_185900_create_payment_methods_table\', 1)\",\"time\":\"5.56\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(228,'a01a4fb7-c786-4496-a6b9-059c2dc8e8e2','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `payments` (`id` bigint unsigned not null auto_increment primary key, `order_id` bigint unsigned not null, `payment_method_id` bigint unsigned null, `transaction_id` varchar(255) not null, `method` varchar(255) null, `gateway` varchar(255) null, `status` enum(\'pending\', \'processing\', \'completed\', \'failed\', \'cancelled\', \'refunded\') not null default \'pending\', `amount` decimal(10, 2) not null, `currency` varchar(3) not null default \'USD\', `gateway_response` json null, `metadata` json null, `processed_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"59.27\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185904_create_payments_table.php\",\"line\":13,\"hash\":\"80d8ff3d7aebbcb8b5d6a0bcf03d216e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(229,'a01a4fb7-efb2-4e98-8a6c-0f8e7b215e4a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `payments` add constraint `payments_order_id_foreign` foreign key (`order_id`) references `orders` (`id`) on delete cascade\",\"time\":\"102.54\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185904_create_payments_table.php\",\"line\":13,\"hash\":\"0a9bdd86af129ca8fe374d140edcc0e0\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(230,'a01a4fb8-1c44-4f8d-b745-4167bb496575','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `payments` add constraint `payments_payment_method_id_foreign` foreign key (`payment_method_id`) references `payment_methods` (`id`) on delete cascade\",\"time\":\"113.82\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185904_create_payments_table.php\",\"line\":13,\"hash\":\"debd89fe749656c912ad77a6431ab6be\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(231,'a01a4fb8-2a6c-4005-b74f-9e1893ccef3d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `payments` add index `payments_order_id_status_index`(`order_id`, `status`)\",\"time\":\"35.88\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185904_create_payments_table.php\",\"line\":13,\"hash\":\"1a093bfd97fcb70442fabeff941af104\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(232,'a01a4fb8-342e-4691-841f-7b777216d0d9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `payments` add unique `payments_transaction_id_unique`(`transaction_id`)\",\"time\":\"24.70\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185904_create_payments_table.php\",\"line\":13,\"hash\":\"7a63cbaf76451bee2e809c4acf3afabd\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(233,'a01a4fb8-387d-4fd4-b059-99bc17131299','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_25_185904_create_payments_table\', 1)\",\"time\":\"10.05\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(234,'a01a4fb8-52ff-490c-b719-0cd932ff18be','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `rewards` (`id` bigint unsigned not null auto_increment primary key, `name` varchar(255) not null, `description` text not null, `points_required` int not null, `type` enum(\'discount\', \'free_shipping\', \'gift\', \'cashback\') not null, `value` json not null, `is_active` tinyint(1) not null default \'1\', `usage_limit` int null, `valid_from` timestamp null, `valid_until` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"60.41\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185925_create_rewards_table.php\",\"line\":13,\"hash\":\"e812028a805444e4af1a5b6d47b83939\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(235,'a01a4fb8-5e6e-427b-aece-bde1a83760a9','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `rewards` add index `rewards_is_active_points_required_index`(`is_active`, `points_required`)\",\"time\":\"28.87\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185925_create_rewards_table.php\",\"line\":13,\"hash\":\"eaccaa275915b8a275f63cc4ad546d4d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(236,'a01a4fb8-634b-4703-8e99-a78964cb49b0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_25_185925_create_rewards_table\', 1)\",\"time\":\"10.62\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(237,'a01a4fb8-7a15-4425-8329-36ed60237586','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `user_points` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned not null, `points` int not null, `type` varchar(255) not null, `source` varchar(255) not null, `order_id` bigint unsigned null, `description` text null, `expires_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"49.26\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185943_create_user_points_table.php\",\"line\":13,\"hash\":\"84ba659bc67b30e1039f6450d0a43495\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(238,'a01a4fb8-a0b2-4982-8361-7ef3a71e3c50','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_points` add constraint `user_points_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"98.54\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185943_create_user_points_table.php\",\"line\":13,\"hash\":\"4374f4b76755c21a790b8a7af23b5593\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:30'),(239,'a01a4fb8-cba6-4483-9dab-9da0b7984ac0','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_points` add constraint `user_points_order_id_foreign` foreign key (`order_id`) references `orders` (`id`) on delete set null\",\"time\":\"109.66\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185943_create_user_points_table.php\",\"line\":13,\"hash\":\"550bad9517f3b48c4989b15afa74fc3f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(240,'a01a4fb8-da4b-4980-90d5-213aa22d247a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_points` add index `user_points_user_id_type_index`(`user_id`, `type`)\",\"time\":\"37.13\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185943_create_user_points_table.php\",\"line\":13,\"hash\":\"b66fef3ec1e4d3c2df91937c44622ff7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(241,'a01a4fb8-e532-4de4-843e-5daf42b19bf5','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_points` add index `user_points_expires_at_index`(`expires_at`)\",\"time\":\"27.50\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_185943_create_user_points_table.php\",\"line\":13,\"hash\":\"8b594fadd35045956b92d82c95c22063\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(242,'a01a4fb8-e8dc-42d5-9219-8ccec40f5e65','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_25_185943_create_user_points_table\', 1)\",\"time\":\"8.27\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(243,'a01a4fb8-fe1a-460c-bcb9-45324965dc4c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `user_behaviors` (`id` bigint unsigned not null auto_increment primary key, `user_id` bigint unsigned not null, `action` varchar(255) not null, `data` json null, `ip_address` varchar(255) null, `user_agent` text null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"45.39\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_190659_create_user_behaviors_table.php\",\"line\":13,\"hash\":\"90ae34251d9002c235345714b37f50e8\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(244,'a01a4fb9-274e-407e-abb4-90f768b95c83','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_behaviors` add constraint `user_behaviors_user_id_foreign` foreign key (`user_id`) references `users` (`id`) on delete cascade\",\"time\":\"105.12\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_190659_create_user_behaviors_table.php\",\"line\":13,\"hash\":\"9f84810d50562d36d645ed3d2564a20b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(245,'a01a4fb9-3533-493b-8f3a-3d8e5adfba6a','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_behaviors` add index `user_behaviors_user_id_action_index`(`user_id`, `action`)\",\"time\":\"35.22\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_190659_create_user_behaviors_table.php\",\"line\":13,\"hash\":\"683b68ba2e7c0c4999767aeec49353b5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(246,'a01a4fb9-400d-4e48-ba73-4516ea251748','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `user_behaviors` add index `user_behaviors_created_at_index`(`created_at`)\",\"time\":\"27.42\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_25_190659_create_user_behaviors_table.php\",\"line\":13,\"hash\":\"5d87e782b2456eaec2b1ba3f9659bfb7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(247,'a01a4fb9-42f0-4a67-bc16-a5da4e6ca212','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_25_190659_create_user_behaviors_table\', 1)\",\"time\":\"6.60\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(248,'a01a4fb9-46ac-4098-9c0d-e81027c638d4','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'products\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.88\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":19,\"hash\":\"8d749ab6b7726b51772f296f86d3a0ff\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(249,'a01a4fb9-4817-4ea3-868d-1b42989b781e','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"3.08\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(250,'a01a4fb9-48ee-4101-9d8c-b7c8e46f1e5f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.72\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(251,'a01a4fb9-4999-492b-8883-7cfc2145cb3b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.42\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(252,'a01a4fb9-4a3d-48ea-9b27-3f95a3373391','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.33\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(253,'a01a4fb9-4b98-42f9-9458-e84fb91f79ae','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'products\' order by ordinal_position asc\",\"time\":\"3.13\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":39,\"hash\":\"56d50dd0c9539d457dd26e1246e9c08d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(254,'a01a4fb9-4c63-42ae-a3cd-d2b636f6036c','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.63\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(255,'a01a4fb9-4d1b-4e0b-acb2-642af908d68b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'products\' order by ordinal_position asc\",\"time\":\"1.50\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":49,\"hash\":\"56d50dd0c9539d457dd26e1246e9c08d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(256,'a01a4fb9-4dc8-4b80-896b-6e05ae572867','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.33\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(257,'a01a4fb9-626b-4aca-9688-4faa9245675b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add index `products_name_index`(`name`)\",\"time\":\"52.40\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":20,\"hash\":\"41a882cf7c1f2f5ee40b2c0e9b1312c4\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(258,'a01a4fb9-79f2-4962-8378-b688a5bf0c74','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add index `products_slug_index`(`slug`)\",\"time\":\"59.88\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":20,\"hash\":\"5242c6c0e825246e49d4559c6719a2fe\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(259,'a01a4fb9-93c0-429f-90c3-f9f3a4af0247','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add index `products_category_id_index`(`category_id`)\",\"time\":\"65.71\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":20,\"hash\":\"7442a2475ff0ce2777b093bb88aa4da6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(260,'a01a4fb9-a627-43af-a2d2-8bfb568645d4','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add index `products_brand_id_index`(`brand_id`)\",\"time\":\"46.80\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":20,\"hash\":\"ff2c3a5edf0fb4681d5006b623fe665b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(261,'a01a4fb9-b607-4193-8019-9ffc6b96a2b8','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add index `products_price_index`(`price`)\",\"time\":\"40.32\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":20,\"hash\":\"cae50dc75829448d84d201fead79820f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(262,'a01a4fb9-c814-4d41-a389-db51151777ab','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add index `products_created_at_index`(`created_at`)\",\"time\":\"45.89\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":20,\"hash\":\"6ae9c2e3d0c00bed6317c751f64e95be\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(263,'a01a4fb9-c8d0-4ddd-ab55-cb354f89edd2','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'orders\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.52\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":60,\"hash\":\"261428391713dd2f39371769678d216a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(264,'a01a4fb9-c978-4f3a-9426-b3e13bd1171b','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.26\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(265,'a01a4fb9-ca13-4cdb-8a44-993d06c0a9bc','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.24\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(266,'a01a4fb9-caba-42cf-8f7f-9fe16ec6c32f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.32\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(267,'a01a4fb9-cb54-4ea3-8577-23cbe155adcb','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.29\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(268,'a01a4fb9-cbe7-4736-bb07-f83cc17cf84d','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.19\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(269,'a01a4fb9-df04-4dd3-a577-f31a13c8a446','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add index `orders_user_id_index`(`user_id`)\",\"time\":\"48.56\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":61,\"hash\":\"1e5ec387d0dee5af5eb1f0e790f7f29c\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(270,'a01a4fba-08da-437b-ad32-bd67b8cd5fd2','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add index `orders_status_index`(`status`)\",\"time\":\"106.75\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":61,\"hash\":\"587f188cbc951fe0b49e29420aad209b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:31'),(271,'a01a4fba-661c-42ab-bb4c-64f1230ddac8','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add index `orders_order_number_index`(`order_number`)\",\"time\":\"238.36\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":61,\"hash\":\"e7edf4612689152ec71bd75ce1855706\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(272,'a01a4fba-d59d-482f-a39a-405d6ea28fcc','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add index `orders_user_status_index`(`user_id`, `status`)\",\"time\":\"285.13\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":61,\"hash\":\"34e6a88c4f94ad59c2977f15102f3dc8\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(273,'a01a4fbb-249d-4d9e-ac12-c44d3b71458e','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add index `orders_created_at_index`(`created_at`)\",\"time\":\"201.95\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":61,\"hash\":\"848c820717b2057be140796dcf0cf343\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(274,'a01a4fbb-2560-47af-a48a-a0fbd0edffd5','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'order_items\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.57\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":86,\"hash\":\"81b41bf23d85b49b3ed85dbf24aa218f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(275,'a01a4fbb-2626-46bf-8a3e-a7753c2528cd','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'order_items\' group by index_name, index_type, non_unique\",\"time\":\"1.55\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"e7803efb3472dd20bbed4d35ea0081fa\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(276,'a01a4fbb-26e0-4139-b66e-eb3f4e876295','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'order_items\' group by index_name, index_type, non_unique\",\"time\":\"1.47\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"e7803efb3472dd20bbed4d35ea0081fa\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(277,'a01a4fbb-4870-401a-ad27-098abac9437f','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `order_items` add index `order_items_order_id_index`(`order_id`)\",\"time\":\"85.33\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":87,\"hash\":\"574570f5e625542e4f5566d301a175c5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(278,'a01a4fbb-66eb-4d39-a114-fd4c73e25831','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `order_items` add index `order_items_product_id_index`(`product_id`)\",\"time\":\"77.42\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":87,\"hash\":\"e301287395a069ad5b866019fa3cdfe0\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(279,'a01a4fbb-67eb-4fe1-943e-cd03f22ee627','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'users\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"2.09\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":99,\"hash\":\"9f3f6c7be4340aeab9da99488bbc5b61\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(280,'a01a4fbb-68ae-41d7-a2db-92f9dba6d237','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'users\' group by index_name, index_type, non_unique\",\"time\":\"1.52\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"cbcaac31c51858e7bfd2ed857a481d12\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(281,'a01a4fbb-69a4-496f-9e01-e724db215cbc','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'users\' group by index_name, index_type, non_unique\",\"time\":\"1.95\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"cbcaac31c51858e7bfd2ed857a481d12\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(282,'a01a4fbb-6aa3-4428-b267-441cc828ca5e','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'users\' group by index_name, index_type, non_unique\",\"time\":\"1.94\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":341,\"hash\":\"cbcaac31c51858e7bfd2ed857a481d12\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(283,'a01a4fbb-91bf-4117-b48d-75785acf78bf','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add index `users_email_index`(`email`)\",\"time\":\"99.67\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":100,\"hash\":\"dbcb90cbe900facfd3aa79645ffdddd1\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(284,'a01a4fbb-b28a-4609-afa9-1022e07239eb','a01a4fbc-c973-424c-b631-b5aeface3dca',NULL,1,'command','{\"command\":\"migrate\",\"exit_code\":1,\"arguments\":{\"command\":\"migrate\"},\"options\":{\"database\":null,\"force\":true,\"path\":[],\"realpath\":false,\"schema-path\":null,\"pretend\":false,\"seed\":false,\"seeder\":null,\"step\":false,\"graceful\":false,\"isolated\":false,\"help\":false,\"silent\":false,\"quiet\":false,\"verbose\":false,\"version\":false,\"ansi\":null,\"no-interaction\":false,\"env\":null},\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:44:32'),(285,'a01a502b-73e8-4d97-a504-19d2618cb821','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'migrations\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"45.30\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"472343cbf78736393ab995dc1735b75f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(286,'a01a502b-c13f-4eb7-9019-97ecc11ae9aa','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'migrations\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.16\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"472343cbf78736393ab995dc1735b75f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(287,'a01a502b-db70-4dab-96ef-ae2bcc0f002c','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select `migration` from `migrations` order by `batch` asc, `migration` asc\",\"time\":\"0.85\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"ed08a59c7f0b8851f0fd2291ca94d5c7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(288,'a01a502b-dcc3-4782-97dc-dd940ca03863','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select `migration` from `migrations` order by `batch` asc, `migration` asc\",\"time\":\"0.58\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"ed08a59c7f0b8851f0fd2291ca94d5c7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(289,'a01a502b-f525-4a4b-a1c0-97c244bb2b1e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select max(`batch`) as aggregate from `migrations`\",\"time\":\"0.58\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"06e60d7b3d1a0c2de504de4e6f27735e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(290,'a01a502c-86cd-40d7-b797-94d3c68c187c','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'products\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.52\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":19,\"hash\":\"8d749ab6b7726b51772f296f86d3a0ff\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(291,'a01a502c-8beb-425d-8bd8-be7e43dbcf01','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.65\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(292,'a01a502c-8c73-47da-91ac-24818ca89b61','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.07\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(293,'a01a502c-8cfd-4ecc-b839-ef2726c85630','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.10\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(294,'a01a502c-8df8-41ed-8f59-d6dc6c22c17c','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"2.11\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(295,'a01a502c-8e97-4223-b023-e1df4f384e9d','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'products\' order by ordinal_position asc\",\"time\":\"1.30\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":39,\"hash\":\"56d50dd0c9539d457dd26e1246e9c08d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(296,'a01a502c-8f26-4383-ad5f-08fdbebdb344','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.15\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(297,'a01a502c-8fb9-418b-9cbf-03bcd6b9c0f2','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'products\' order by ordinal_position asc\",\"time\":\"1.12\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":49,\"hash\":\"56d50dd0c9539d457dd26e1246e9c08d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(298,'a01a502c-9044-413e-8338-3550e2febeaa','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'products\' group by index_name, index_type, non_unique\",\"time\":\"1.12\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"90dce3ab3144eea93f23ad80a12f5877\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(299,'a01a502c-90c6-4a55-af59-734b927c8e6d','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'orders\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.05\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":60,\"hash\":\"261428391713dd2f39371769678d216a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(300,'a01a502c-914b-4cf1-ba53-478eef16d1ea','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.07\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(301,'a01a502c-91d7-4785-bd44-8b09424ba790','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'orders\' order by ordinal_position asc\",\"time\":\"1.17\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":67,\"hash\":\"6019fd19801dbaa19e62aec40a557bcb\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(302,'a01a502c-9264-40df-a7b4-cab01b17dd8e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.16\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(303,'a01a502c-92e6-451a-8946-b25aff976618','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.06\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(304,'a01a502c-9377-4e30-bc66-55c5a19f261e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'orders\' order by ordinal_position asc\",\"time\":\"1.19\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":76,\"hash\":\"6019fd19801dbaa19e62aec40a557bcb\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(305,'a01a502c-948f-40d6-bb63-54f50c6a232f','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'orders\' order by ordinal_position asc\",\"time\":\"2.37\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":76,\"hash\":\"6019fd19801dbaa19e62aec40a557bcb\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(306,'a01a502c-9541-459f-94f8-2cdab6becf68','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.46\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(307,'a01a502c-95ef-4f85-b0a3-ab35015c4809','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'orders\' group by index_name, index_type, non_unique\",\"time\":\"1.39\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"23530f764c693767b1639d584e3c4c2d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(308,'a01a502c-969e-47f0-9796-31484ba10c08','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'order_items\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.29\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":87,\"hash\":\"81b41bf23d85b49b3ed85dbf24aa218f\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(309,'a01a502c-977b-4424-9c3b-61a03f5a739f','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'order_items\' group by index_name, index_type, non_unique\",\"time\":\"1.78\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"e7803efb3472dd20bbed4d35ea0081fa\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(310,'a01a502c-982b-4f28-a5ac-4ff84406edff','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'order_items\' group by index_name, index_type, non_unique\",\"time\":\"1.43\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"e7803efb3472dd20bbed4d35ea0081fa\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(311,'a01a502c-98c9-4068-b237-842ec728655e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'users\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.17\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":100,\"hash\":\"9f3f6c7be4340aeab9da99488bbc5b61\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(312,'a01a502c-995f-4c5e-8e72-a61bcfd9a4af','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'users\' group by index_name, index_type, non_unique\",\"time\":\"1.20\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"cbcaac31c51858e7bfd2ed857a481d12\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(313,'a01a502c-9a61-48dc-9242-9139dba62f34','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'users\' order by ordinal_position asc\",\"time\":\"2.10\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":107,\"hash\":\"cc0cc7e6dff5ba2255c65426c5f591e9\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(314,'a01a502c-9b18-4b8c-9e40-b64c35db125a','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'users\' group by index_name, index_type, non_unique\",\"time\":\"1.47\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"cbcaac31c51858e7bfd2ed857a481d12\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:46'),(315,'a01a502c-b66f-4233-8768-63a76502b66b','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add index `users_created_at_index`(`created_at`)\",\"time\":\"56.93\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":101,\"hash\":\"ad893a9c595d4149c0083f0d7b8a865e\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(316,'a01a502c-b725-484d-ba65-54756db5da0e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'categories\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.48\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":118,\"hash\":\"a4a74ad78d92597c88224a79b7e76260\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(317,'a01a502c-b7d1-4128-a228-bf660e797f8e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'categories\' group by index_name, index_type, non_unique\",\"time\":\"1.36\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"978c6ddd9f10c2fb2d924fc0c6f87bfc\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(318,'a01a502c-b88c-4f64-bfe1-6a7b0b0aff9b','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'categories\' group by index_name, index_type, non_unique\",\"time\":\"1.52\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"978c6ddd9f10c2fb2d924fc0c6f87bfc\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(319,'a01a502c-b962-4624-92f6-62ddf87be605','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'categories\' order by ordinal_position asc\",\"time\":\"1.79\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":129,\"hash\":\"025886e97d189f692581ba15b77853e8\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(320,'a01a502c-c82b-49cb-a951-d596a1047065','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `categories` add index `categories_slug_index`(`slug`)\",\"time\":\"37.51\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":119,\"hash\":\"26be3ee26dfa909a71ad3779c2066e87\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(321,'a01a502c-d991-45ac-8250-51d3a3a5718b','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `categories` add index `categories_parent_id_index`(`parent_id`)\",\"time\":\"44.23\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":119,\"hash\":\"5c3937cd1117e2f652e383b28ea84058\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(322,'a01a502c-da53-4858-a0fc-f733dc2bf227','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'reviews\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.62\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":136,\"hash\":\"626f56cf1e865a285780e33012a812e5\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(323,'a01a502c-daf1-4fec-b33b-f6052b0240ff','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'reviews\' group by index_name, index_type, non_unique\",\"time\":\"1.27\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"c0a2b6762e1fa02fcc8aa43c4bf476c7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(324,'a01a502c-db9c-4111-bb27-42f1fa736e09','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'reviews\' group by index_name, index_type, non_unique\",\"time\":\"1.28\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"c0a2b6762e1fa02fcc8aa43c4bf476c7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(325,'a01a502c-dc4b-4806-b6cd-e2659022f651','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'reviews\' group by index_name, index_type, non_unique\",\"time\":\"1.47\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"c0a2b6762e1fa02fcc8aa43c4bf476c7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(326,'a01a502c-dceb-4c11-b46c-0d7e7f9bfdbd','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'reviews\' group by index_name, index_type, non_unique\",\"time\":\"1.30\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"c0a2b6762e1fa02fcc8aa43c4bf476c7\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(327,'a01a502c-eb01-478c-8987-ba9039315065','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `reviews` add index `reviews_product_id_index`(`product_id`)\",\"time\":\"35.66\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":137,\"hash\":\"f230b8c57a80e996545b621eb484ae83\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(328,'a01a502c-f827-4b0f-b46e-2a5b1f33907a','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `reviews` add index `reviews_user_id_index`(`user_id`)\",\"time\":\"33.33\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":137,\"hash\":\"5df1591c45ad1edfbdfe150858e0f019\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(329,'a01a502d-046c-4995-9a55-812e3ab2718b','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `reviews` add index `reviews_rating_index`(`rating`)\",\"time\":\"31.05\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":137,\"hash\":\"e68e15cd3b174ecc8d6395f1afd6ffb2\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(330,'a01a502d-1223-4f7b-aba4-4949cc262159','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `reviews` add index `reviews_product_rating_index`(`product_id`, `rating`)\",\"time\":\"34.65\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":137,\"hash\":\"dd92e0b154d11f2ea348add34cfb8651\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(331,'a01a502d-12f2-4240-9677-9b639f9705cf','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'carts\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.71\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":158,\"hash\":\"06fbe811dbedf497897f4979d0d24013\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(332,'a01a502d-137f-4b46-aed3-5dbfa3e13b2f','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'wishlists\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.13\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":171,\"hash\":\"8fad44440b03126e3e02c460a89d07c6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(333,'a01a502d-141f-4692-9117-9c4a50b6b37b','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'wishlists\' group by index_name, index_type, non_unique\",\"time\":\"1.30\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"4f6feb2b3e9862e9f59125750790d1e6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(334,'a01a502d-14b3-4284-b9dd-643517b1e89e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'wishlists\' group by index_name, index_type, non_unique\",\"time\":\"1.21\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"4f6feb2b3e9862e9f59125750790d1e6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(335,'a01a502d-154e-40a4-afa1-6c3ccbeca5db','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'wishlists\' group by index_name, index_type, non_unique\",\"time\":\"1.24\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"4f6feb2b3e9862e9f59125750790d1e6\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(336,'a01a502d-203d-404a-b501-09b8566c8d65','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `wishlists` add index `wishlists_user_id_index`(`user_id`)\",\"time\":\"27.53\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":172,\"hash\":\"29e85cede9822da1ebb87bb89cf93c88\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(337,'a01a502d-32a4-46f4-b020-61eb6d35a40d','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `wishlists` add index `wishlists_product_id_index`(`product_id`)\",\"time\":\"46.80\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":172,\"hash\":\"232c8b986b52d8077cd23ae5a35bffd0\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(338,'a01a502d-3dc0-4db1-8cee-b59068394307','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `wishlists` add unique `wishlists_user_product_unique`(`user_id`, `product_id`)\",\"time\":\"28.08\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":172,\"hash\":\"c6f399bd69a04c124174343639bdc7da\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(339,'a01a502d-3e64-44a4-83cd-60d3e41a3c2d','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'payments\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.33\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":189,\"hash\":\"8be1d87f2bb317eca69a65956742065a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(340,'a01a502d-3f12-4d6c-bbfe-2cc10228f7b4','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'payments\' group by index_name, index_type, non_unique\",\"time\":\"1.33\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"370c45f4f9dc4c8094bab371e155a4fe\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(341,'a01a502d-3fb0-45e7-8106-b11940a33f41','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'payments\' group by index_name, index_type, non_unique\",\"time\":\"1.31\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"370c45f4f9dc4c8094bab371e155a4fe\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(342,'a01a502d-4050-4fc7-bab4-b39b0e38776d','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'payments\' order by ordinal_position asc\",\"time\":\"1.32\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":200,\"hash\":\"98bfccfe7a246b0d39711b8e1fe0f592\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(343,'a01a502d-40e6-4ffb-bd11-366d4b8c2abb','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'payments\' group by index_name, index_type, non_unique\",\"time\":\"1.23\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"370c45f4f9dc4c8094bab371e155a4fe\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(344,'a01a502d-5000-4a6c-a557-c5bf234d7565','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `payments` add index `payments_order_id_index`(`order_id`)\",\"time\":\"38.23\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":190,\"hash\":\"d296a65c87e21730f1c001824a12272a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(345,'a01a502d-5cce-4c8e-bc18-d23f287c2067','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `payments` add index `payments_transaction_id_index`(`transaction_id`)\",\"time\":\"32.42\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":190,\"hash\":\"d444800468df5d453b6de64a8ea427e1\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(346,'a01a502d-6ab6-4859-86f9-f1cb66d687b2','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `payments` add index `payments_status_index`(`status`)\",\"time\":\"35.24\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":190,\"hash\":\"7e96aa9823ab7c2d8b12b393f72fdf46\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(347,'a01a502d-6b8b-4566-9112-8bbe6cbb15e7','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'notifications\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.70\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":207,\"hash\":\"ad768e681c40409b9c8fa4db3d841f2a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(348,'a01a502d-6c3d-4017-be4d-d9bcff50e804','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'notifications\' group by index_name, index_type, non_unique\",\"time\":\"1.43\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"3409299cfe865975c29d8e6635ba175d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(349,'a01a502d-6cdf-4f0c-b04c-10355b7e44d1','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'notifications\' group by index_name, index_type, non_unique\",\"time\":\"1.29\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"3409299cfe865975c29d8e6635ba175d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(350,'a01a502d-7a3e-411b-a75a-50f83cf11517','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `notifications` add index `notifications_notifiable_index`(`notifiable_type`, `notifiable_id`)\",\"time\":\"33.89\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":208,\"hash\":\"783c10a7eff14a62ae6b205d2a1cddda\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(351,'a01a502d-9986-4191-8b39-2dfc994df5ad','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `notifications` add index `notifications_read_at_index`(`read_at`)\",\"time\":\"79.66\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":208,\"hash\":\"beffbc2f5e022d2c02a607ac1ddda864\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(352,'a01a502d-9a55-4ec7-919d-9ebe1dc5c79a','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'activity_log\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.63\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":220,\"hash\":\"e7be4b9dd2cc77f73ce0340f3b6bf149\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(353,'a01a502d-9b0c-4899-a174-69b5d598a15b','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'sessions\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.41\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":237,\"hash\":\"b0098f2bc88b2c5edd8fbd62e6e2abe1\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(354,'a01a502d-9bc9-4d28-b712-9666f3f9f2df','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'sessions\' group by index_name, index_type, non_unique\",\"time\":\"1.41\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"2d7a029f67408d7f62cd27f83ea4a893\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(355,'a01a502d-9c7b-4ff7-8d8b-676ae3b6318e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select index_name as `name`, group_concat(column_name order by seq_in_index) as `columns`, index_type as `type`, not non_unique as `unique` from information_schema.statistics where table_schema = schema() and table_name = \'sessions\' group by index_name, index_type, non_unique\",\"time\":\"1.34\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":345,\"hash\":\"2d7a029f67408d7f62cd27f83ea4a893\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(356,'a01a502d-af72-47c6-90f0-e85af302e49f','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `sessions` add index `sessions_user_id_index`(`user_id`)\",\"time\":\"48.21\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":238,\"hash\":\"143e0209095c4f5cecfdd51a11268572\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(357,'a01a502d-c42c-40aa-997f-29f51dec17a5','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `sessions` add index `sessions_last_activity_index`(`last_activity`)\",\"time\":\"52.70\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_09_30_000001_add_performance_indexes.php\",\"line\":238,\"hash\":\"5102944fa5d480fdd2bbfbfe1a0c03bc\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(358,'a01a502d-d120-4ede-aa5f-c89b0396dc42','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_09_30_000001_add_performance_indexes\', 2)\",\"time\":\"9.20\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(359,'a01a502d-fd9a-49e5-b827-411574de2e47','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `exchange_rates` (`id` bigint unsigned not null auto_increment primary key, `from_currency` varchar(3) not null, `to_currency` varchar(3) not null, `rate` decimal(20, 10) not null, `source` varchar(255) not null default \'manual\', `fetched_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"86.00\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000001_create_exchange_rates_table.php\",\"line\":16,\"hash\":\"06415ee93fb5c947709ca9966a4c94dc\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(360,'a01a502e-0b9b-4980-af1f-a848aa78315f','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `exchange_rates` add unique `exchange_rates_from_currency_to_currency_unique`(`from_currency`, `to_currency`)\",\"time\":\"35.54\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000001_create_exchange_rates_table.php\",\"line\":16,\"hash\":\"64000d27630b283140e3d92926dbdc3a\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(361,'a01a502e-1a2a-4d26-8626-d7190e17128c','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `exchange_rates` add index `exchange_rates_from_currency_to_currency_updated_at_index`(`from_currency`, `to_currency`, `updated_at`)\",\"time\":\"36.89\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000001_create_exchange_rates_table.php\",\"line\":16,\"hash\":\"b3b79e5bcb37b62b764636f2440e6c93\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(362,'a01a502e-26a4-4e95-8cc1-29d67b07426e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `exchange_rates` add index `exchange_rates_from_currency_index`(`from_currency`)\",\"time\":\"31.54\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000001_create_exchange_rates_table.php\",\"line\":16,\"hash\":\"23f86da0d87a38ef6a5317d5a2a96f18\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(363,'a01a502e-34f6-41df-93e0-023c846d17fe','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `exchange_rates` add index `exchange_rates_to_currency_index`(`to_currency`)\",\"time\":\"36.26\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000001_create_exchange_rates_table.php\",\"line\":16,\"hash\":\"cac35d9d628289453b768fc3cfe0f757\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:47'),(364,'a01a502e-37c8-4f47-9dee-c80802aa44d4','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_10_01_000001_create_exchange_rates_table\', 2)\",\"time\":\"6.36\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(365,'a01a502e-9c4d-4a45-ac06-e8f1c7e12796','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `webhooks` (`id` bigint unsigned not null auto_increment primary key, `store_identifier` varchar(50) not null, `event_type` varchar(50) not null, `product_identifier` varchar(100) not null, `product_id` bigint unsigned null, `payload` json not null, `signature` varchar(255) null, `status` enum(\'pending\', \'processing\', \'completed\', \'failed\') not null default \'pending\', `error_message` text null, `processed_at` timestamp null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"51.39\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":16,\"hash\":\"5ec921ceab5a1088c9442a093a43cfa1\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(366,'a01a502e-c573-4ce4-ab24-a39ada155c9f','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `webhooks` add constraint `webhooks_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"105.01\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":16,\"hash\":\"df372b212038ab49d87389d03a2ba774\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(367,'a01a502f-01ba-4eb2-8c60-edb0c87a4c76','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `webhooks` add index `webhooks_store_identifier_event_type_index`(`store_identifier`, `event_type`)\",\"time\":\"153.99\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":16,\"hash\":\"899c71e400084a3c639802ed91735bbf\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(368,'a01a502f-149c-4733-9c5e-8551835de99d','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `webhooks` add index `webhooks_status_created_at_index`(`status`, `created_at`)\",\"time\":\"48.02\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":16,\"hash\":\"b100026e6dc4d58cfe955b715ecfef1b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(369,'a01a502f-2729-4c4b-bd3d-81adc8327d12','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `webhooks` add index `webhooks_store_identifier_index`(`store_identifier`)\",\"time\":\"46.69\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":16,\"hash\":\"8b5555e6856b0b3d8392a092fc0540fb\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(370,'a01a502f-37d2-4144-8805-452ed9930988','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `webhooks` add index `webhooks_event_type_index`(`event_type`)\",\"time\":\"42.32\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":16,\"hash\":\"060f0cfa8eec6edc0e95caa6b561a125\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(371,'a01a502f-4847-4b4c-9039-82c537f71448','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `webhooks` add index `webhooks_status_index`(`status`)\",\"time\":\"41.71\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":16,\"hash\":\"aee45b7e6e7cfbb20b5c86ac77347152\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(372,'a01a502f-5a81-4104-a45e-947e808e1304','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `webhook_logs` (`id` bigint unsigned not null auto_increment primary key, `webhook_id` bigint unsigned not null, `action` varchar(50) not null, `message` text not null, `metadata` json null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"45.95\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":34,\"hash\":\"c0d3b635f2f1663f9290c0ae6b890eba\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(373,'a01a502f-8c5c-4e8c-89ca-db7fbbaf139a','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `webhook_logs` add constraint `webhook_logs_webhook_id_foreign` foreign key (`webhook_id`) references `webhooks` (`id`) on delete cascade\",\"time\":\"127.30\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":34,\"hash\":\"64c024c443099ec33acac9646c152377\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(374,'a01a502f-9980-4107-890d-97c7fb7dfb6f','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `webhook_logs` add index `webhook_logs_webhook_id_index`(`webhook_id`)\",\"time\":\"33.17\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_01_000003_create_webhooks_table.php\",\"line\":34,\"hash\":\"39affd574cc2a8882d5f7ca947c4fa84\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(375,'a01a502f-9d96-4907-aee8-70003bb360bf','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_10_01_000003_create_webhooks_table\', 2)\",\"time\":\"9.41\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(376,'a01a502f-b802-4309-8b84-83aa86cf36ea','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `price_histories` (`id` bigint unsigned not null auto_increment primary key, `product_id` bigint unsigned not null, `price` decimal(8, 2) not null, `effective_date` timestamp not null, `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"58.02\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_02_000000_create_price_histories_table.php\",\"line\":16,\"hash\":\"8430361d6cda13c2f9d9c3c7788d82d4\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:48'),(377,'a01a502f-e3a9-4dd8-b8ca-e79c0a6a0933','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `price_histories` add constraint `price_histories_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"111.33\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_02_000000_create_price_histories_table.php\",\"line\":16,\"hash\":\"876d7d7f8eb12a29fa764d3253f40405\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(378,'a01a502f-e70e-42e8-8edb-b98c9c399621','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_10_02_000000_create_price_histories_table\', 2)\",\"time\":\"7.84\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(379,'a01a502f-e9e2-4c12-a6ae-dc181a9608b3','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'users\' order by ordinal_position asc\",\"time\":\"1.97\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_08_000001_add_phone_and_email_validation_to_users_table.php\",\"line\":15,\"hash\":\"cc0cc7e6dff5ba2255c65426c5f591e9\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(380,'a01a5030-1455-4cad-84d0-ffd068b7864a','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `users` add `phone` varchar(20) null after `is_admin`\",\"time\":\"108.03\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_08_000001_add_phone_and_email_validation_to_users_table.php\",\"line\":16,\"hash\":\"9a53e6d7e2f818bd643a72143a26adda\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(381,'a01a5030-1cd7-493f-bba4-814cdb335471','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_10_08_000001_add_phone_and_email_validation_to_users_table\', 2)\",\"time\":\"6.02\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(382,'a01a5030-1fc8-49f0-a9e7-ae2ba7626bca','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'orders\' order by ordinal_position asc\",\"time\":\"1.99\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_08_000002_add_order_date_validation_to_orders_table.php\",\"line\":15,\"hash\":\"6019fd19801dbaa19e62aec40a557bcb\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(383,'a01a5030-6d41-4430-b01a-487b06500e09','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `orders` add `order_date` datetime null after `delivered_at`\",\"time\":\"197.86\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_08_000002_add_order_date_validation_to_orders_table.php\",\"line\":16,\"hash\":\"38e18aa0e1d82aed935635c5c827f853\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(384,'a01a5030-7120-4c3e-9db1-80324ef3419c','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_10_08_000002_add_order_date_validation_to_orders_table\', 2)\",\"time\":\"9.21\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(385,'a01a5030-750b-44fd-b487-a7e57ca7a647','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'products\' order by ordinal_position asc\",\"time\":\"2.18\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163500_add_currency_id_to_products_table.php\",\"line\":14,\"hash\":\"56d50dd0c9539d457dd26e1246e9c08d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(386,'a01a5030-b9d2-48be-9922-0cfd8260a05b','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add `currency_id` bigint unsigned null\",\"time\":\"175.44\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163500_add_currency_id_to_products_table.php\",\"line\":15,\"hash\":\"5b129c90370c84aeaa3c4ea9fb405834\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(387,'a01a5031-0762-4529-be90-217c23f21646','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add constraint `products_currency_id_foreign` foreign key (`currency_id`) references `currencies` (`id`) on delete set null\",\"time\":\"198.27\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163500_add_currency_id_to_products_table.php\",\"line\":15,\"hash\":\"8f2121c249db73eed8b6713989efc4c0\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(388,'a01a5031-0ba5-4209-8ca0-ad2f3b53aa95','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_10_09_163500_add_currency_id_to_products_table\', 2)\",\"time\":\"9.96\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(389,'a01a5031-2340-4b12-9926-33f213cffc42','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"create table `product_store` (`id` bigint unsigned not null auto_increment primary key, `product_id` bigint unsigned not null, `store_id` bigint unsigned not null, `price` decimal(8, 2) not null, `currency_id` bigint unsigned null, `is_available` tinyint(1) not null default \'1\', `created_at` timestamp null, `updated_at` timestamp null) default character set utf8mb4 collate \'utf8mb4_unicode_ci\'\",\"time\":\"50.78\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163600_create_product_store_pivot_table.php\",\"line\":16,\"hash\":\"f577071b24d32da55d07199801d1bc88\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:49'),(390,'a01a5031-4dec-446d-94f3-23cd64e242a2','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `product_store` add constraint `product_store_product_id_foreign` foreign key (`product_id`) references `products` (`id`) on delete cascade\",\"time\":\"108.90\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163600_create_product_store_pivot_table.php\",\"line\":16,\"hash\":\"7235e93c89f6d6602c72ebd585c8a937\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(391,'a01a5031-7b5a-4713-8304-5dfd4e0a5664','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `product_store` add constraint `product_store_store_id_foreign` foreign key (`store_id`) references `stores` (`id`) on delete cascade\",\"time\":\"115.93\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163600_create_product_store_pivot_table.php\",\"line\":16,\"hash\":\"e30c85835e32cafdcd495f382e856a0b\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(392,'a01a5031-ad1d-4726-8bf7-2145b62dc68c','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `product_store` add constraint `product_store_currency_id_foreign` foreign key (`currency_id`) references `currencies` (`id`) on delete set null\",\"time\":\"127.05\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163600_create_product_store_pivot_table.php\",\"line\":16,\"hash\":\"e64c5f4ebe0007249f0a7fb93c12b2c1\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(393,'a01a5031-bccd-4724-9271-75cc703d4c3e','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `product_store` add unique `product_store_product_id_store_id_unique`(`product_id`, `store_id`)\",\"time\":\"39.85\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163600_create_product_store_pivot_table.php\",\"line\":16,\"hash\":\"e41d54aff01a7b0a8eb9e5eb21655acc\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(394,'a01a5031-c7a9-409f-a4db-93e07a9d6cec','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `product_store` add index `product_store_product_id_is_available_index`(`product_id`, `is_available`)\",\"time\":\"27.47\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163600_create_product_store_pivot_table.php\",\"line\":16,\"hash\":\"93333a7d33d42851d26f13445e30f29d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(395,'a01a5031-ca99-4e38-be9f-575d84622abe','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_10_09_163600_create_product_store_pivot_table\', 2)\",\"time\":\"6.68\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(396,'a01a5031-cd4d-4059-90f4-e52797f3581c','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select exists (select 1 from information_schema.tables where table_schema = schema() and table_name = \'products\' and table_type in (\'BASE TABLE\', \'SYSTEM VERSIONED\')) as `exists`\",\"time\":\"1.59\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163700_add_quantity_to_products_table.php\",\"line\":16,\"hash\":\"8d749ab6b7726b51772f296f86d3a0ff\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(397,'a01a5031-cdf3-48c2-a126-ebc3c3992c6b','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"select column_name as `name`, data_type as `type_name`, column_type as `type`, collation_name as `collation`, is_nullable as `nullable`, column_default as `default`, column_comment as `comment`, generation_expression as `expression`, extra as `extra` from information_schema.columns where table_schema = schema() and table_name = \'products\' order by ordinal_position asc\",\"time\":\"1.36\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163700_add_quantity_to_products_table.php\",\"line\":16,\"hash\":\"56d50dd0c9539d457dd26e1246e9c08d\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(398,'a01a5032-19ce-4d8c-ae42-e2123acd2abe','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"alter table `products` add `quantity` int not null default \'0\'\",\"time\":\"193.62\",\"slow\":true,\"file\":\"\\/var\\/www\\/html\\/database\\/migrations\\/2025_10_09_163700_add_quantity_to_products_table.php\",\"line\":17,\"hash\":\"5feeb981cd1d222ad0cc0de0bd3d79fe\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(399,'a01a5032-1dd4-42f3-9c5c-31590ac12ba5','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'query','{\"connection\":\"mysql\",\"driver\":\"mysql\",\"bindings\":[],\"sql\":\"insert into `migrations` (`migration`, `batch`) values (\'2025_10_09_163700_add_quantity_to_products_table\', 2)\",\"time\":\"9.48\",\"slow\":false,\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35,\"hash\":\"f2b8e8e4266db16aec6db940c643eb68\",\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(400,'a01a5032-35ae-4bfe-925b-bf8361f2ccde','a01a5032-4e43-4e8c-8b73-c453651309c0',NULL,1,'command','{\"command\":\"migrate\",\"exit_code\":0,\"arguments\":{\"command\":\"migrate\"},\"options\":{\"database\":null,\"force\":true,\"path\":[],\"realpath\":false,\"schema-path\":null,\"pretend\":false,\"seed\":false,\"seeder\":null,\"step\":false,\"graceful\":false,\"isolated\":false,\"help\":false,\"silent\":false,\"quiet\":false,\"verbose\":false,\"version\":false,\"ansi\":null,\"no-interaction\":false,\"env\":null},\"hostname\":\"f8eb3521363d\"}','2025-10-13 09:45:50'),(401,'a01a5091-533a-412a-b34c-38396b3a53cc','a01a5092-19c2-4033-aa79-348c9d1a326c','6c576f4b57a8aa2063ee0e185b8e6491',1,'exception','{\"class\":\"Symfony\\\\Component\\\\Console\\\\Exception\\\\CommandNotFoundException\",\"file\":\"\\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":743,\"message\":\"Command \\\"test\\\" is not defined.\\n\\nDid you mean one of these?\\n    make:test\\n    schedule:test\",\"context\":null,\"trace\":[{\"file\":\"\\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":301},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/symfony\\/console\\/Application.php\",\"line\":194},{\"file\":\"\\/var\\/www\\/html\\/vendor\\/laravel\\/framework\\/src\\/Illuminate\\/Foundation\\/Console\\/Kernel.php\",\"line\":197},{\"file\":\"\\/var\\/www\\/html\\/artisan\",\"line\":35}],\"line_preview\":{\"734\":\"\",\"735\":\"                if (1 == \\\\count($alternatives)) {\",\"736\":\"                    $message .= \\\"\\\\n\\\\nDid you mean this?\\\\n    \\\";\",\"737\":\"                } else {\",\"738\":\"                    $message .= \\\"\\\\n\\\\nDid you mean one of these?\\\\n    \\\";\",\"739\":\"                }\",\"740\":\"                $message .= implode(\\\"\\\\n    \\\", $alternatives);\",\"741\":\"            }\",\"742\":\"\",\"743\":\"            throw new CommandNotFoundException($message, array_values($alternatives));\",\"744\":\"        }\",\"745\":\"\",\"746\":\"        \\/\\/ filter out aliases for commands which are already on the list\",\"747\":\"        if (\\\\count($commands) > 1) {\",\"748\":\"            $commandList = $this->commandLoader ? array_merge(array_flip($this->commandLoader->getNames()), $this->commands) : $this->commands;\",\"749\":\"            $commands = array_unique(array_filter($commands, function ($nameOrAlias) use (&$commandList, $commands, &$aliases) {\",\"750\":\"                if (!$commandList[$nameOrAlias] instanceof Command) {\",\"751\":\"                    $commandList[$nameOrAlias] = $this->commandLoader->get($nameOrAlias);\",\"752\":\"                }\",\"753\":\"\"},\"hostname\":\"f8eb3521363d\",\"occurrences\":1}','2025-10-13 09:46:53');
/*!40000 ALTER TABLE `telescope_entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_entries_tags`
--

DROP TABLE IF EXISTS `telescope_entries_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telescope_entries_tags` (
  `entry_uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`entry_uuid`,`tag`),
  KEY `telescope_entries_tags_tag_index` (`tag`),
  CONSTRAINT `telescope_entries_tags_entry_uuid_foreign` FOREIGN KEY (`entry_uuid`) REFERENCES `telescope_entries` (`uuid`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_entries_tags`
--

LOCK TABLES `telescope_entries_tags` WRITE;
/*!40000 ALTER TABLE `telescope_entries_tags` DISABLE KEYS */;
INSERT INTO `telescope_entries_tags` VALUES ('a01a4fa3-5977-42d3-9999-41b12e6615c5','slow'),('a01a4fa3-98e9-47c8-b63d-a3c636273048','slow'),('a01a4fa3-d023-40e6-adc8-187d396471fc','slow'),('a01a4fa4-909f-4d3d-864e-6334ac6807f7','slow'),('a01a4fa5-41eb-4c03-b0f4-e90e0aa603f7','slow'),('a01a4fa6-0dcb-48f8-88d1-24384caab0d0','slow'),('a01a4fa7-e2c2-4518-898f-b1f9643b4157','slow'),('a01a4fa8-6b93-43cb-8f6c-521b842724bd','slow'),('a01a4fa8-a87c-43ea-a7e4-a3b775e3cbab','slow'),('a01a4fa8-fbe7-48f1-aa0f-97870e1a1b75','slow'),('a01a4fa9-2ba5-46fb-bc83-c1d2172fe5a6','slow'),('a01a4faa-17be-441d-be28-e72013158049','slow'),('a01a4faa-5984-4650-b3f0-495e8a6ff38c','slow'),('a01a4faa-8d84-4d03-a5f1-76c4509887ed','slow'),('a01a4faa-ed4f-4662-a4f4-a0f28ffbe968','slow'),('a01a4fab-d505-4b49-85c7-873ad3fe36a5','slow'),('a01a4fac-3690-4a15-80b1-57670fa41328','slow'),('a01a4fac-6e71-4429-a919-790e4f1c3125','slow'),('a01a4fac-e003-4f7e-9b7c-f38c6327f3b3','slow'),('a01a4fad-319b-41bb-bcd4-34fe57c6307c','slow'),('a01a4fad-5e49-48a8-9df8-0624f76ae30d','slow'),('a01a4fad-a596-448b-9974-c618e4723120','slow'),('a01a4fad-d5eb-46c6-9c7e-58190c805984','slow'),('a01a4fae-7ce6-4326-a63e-1a8fc0a96cc9','slow'),('a01a4fae-ad24-4281-b59d-2859a321c50c','slow'),('a01a4faf-3cb5-4ee3-bdf2-b6f7829b20b9','slow'),('a01a4faf-a441-41ac-bbcb-6b380d105282','slow'),('a01a4faf-d38e-45ba-9104-3375235102bf','slow'),('a01a4fb0-102b-495a-9eab-0a813ca81da9','slow'),('a01a4fb0-3d7c-47ce-8c6f-d93505cc6c7b','slow'),('a01a4fb0-bfa6-46a1-8410-4f3dd051d2cb','slow'),('a01a4fb0-fdd7-49f0-b2fc-e5c5c69732d7','slow'),('a01a4fb1-3f9d-497e-bf55-2729676422eb','slow'),('a01a4fb1-78f3-4bba-a374-e21bb0df7e4a','slow'),('a01a4fb1-b4a3-4565-964d-a462154f19cc','slow'),('a01a4fb1-e3ca-4388-974e-4ed1cdab64af','slow'),('a01a4fb2-1322-43c2-ba24-eb6bc7b4c827','slow'),('a01a4fb2-4321-4585-bffc-f7cf656d7592','slow'),('a01a4fb2-73c8-4b98-b97d-e89f0c65a13a','slow'),('a01a4fb2-e6cb-4711-ada8-a67c9f96ce38','slow'),('a01a4fb3-4017-4955-851c-8a659ef02fb6','slow'),('a01a4fb3-d477-4c46-9b2b-f995ab4b7ae4','slow'),('a01a4fb4-8038-4648-bce1-4846dbcd77f1','slow'),('a01a4fb4-cb9b-4ff4-baf5-cf31d70800ea','slow'),('a01a4fb4-fb82-4e74-bd6a-0ec3e1c58dc6','slow'),('a01a4fb5-384d-4480-9a8a-2fea5ff1db1f','slow'),('a01a4fb5-97a6-465a-a01b-b86c8982edbe','slow'),('a01a4fb5-c6ab-4460-8220-aeca7c20f712','slow'),('a01a4fb6-1931-4a2f-bfda-8fb320475291','slow'),('a01a4fb6-e94a-4fd8-bc84-573d7229e282','slow'),('a01a4fb7-494e-4ef4-84ab-c58f98a8aa06','slow'),('a01a4fb7-758c-4534-95d2-eaa6b879f0fa','slow'),('a01a4fb7-efb2-4e98-8a6c-0f8e7b215e4a','slow'),('a01a4fb8-1c44-4f8d-b745-4167bb496575','slow'),('a01a4fb8-cba6-4483-9dab-9da0b7984ac0','slow'),('a01a4fb9-274e-407e-abb4-90f768b95c83','slow'),('a01a4fba-08da-437b-ad32-bd67b8cd5fd2','slow'),('a01a4fba-661c-42ab-bb4c-64f1230ddac8','slow'),('a01a4fba-d59d-482f-a39a-405d6ea28fcc','slow'),('a01a4fbb-249d-4d9e-ac12-c44d3b71458e','slow'),('a01a502e-c573-4ce4-ab24-a39ada155c9f','slow'),('a01a502f-01ba-4eb2-8c60-edb0c87a4c76','slow'),('a01a502f-8c5c-4e8c-89ca-db7fbbaf139a','slow'),('a01a502f-e3a9-4dd8-b8ca-e79c0a6a0933','slow'),('a01a5030-1455-4cad-84d0-ffd068b7864a','slow'),('a01a5030-6d41-4430-b01a-487b06500e09','slow'),('a01a5030-b9d2-48be-9922-0cfd8260a05b','slow'),('a01a5031-0762-4529-be90-217c23f21646','slow'),('a01a5031-4dec-446d-94f3-23cd64e242a2','slow'),('a01a5031-7b5a-4713-8304-5dfd4e0a5664','slow'),('a01a5031-ad1d-4726-8bf7-2145b62dc68c','slow'),('a01a5032-19ce-4d8c-ae42-e2123acd2abe','slow');
/*!40000 ALTER TABLE `telescope_entries_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `telescope_monitoring`
--

DROP TABLE IF EXISTS `telescope_monitoring`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `telescope_monitoring` (
  `tag` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `telescope_monitoring`
--

LOCK TABLES `telescope_monitoring` WRITE;
/*!40000 ALTER TABLE `telescope_monitoring` DISABLE KEYS */;
/*!40000 ALTER TABLE `telescope_monitoring` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_behaviors`
--

DROP TABLE IF EXISTS `user_behaviors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_behaviors` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` json DEFAULT NULL,
  `ip_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_behaviors_user_id_action_index` (`user_id`,`action`),
  KEY `user_behaviors_created_at_index` (`created_at`),
  CONSTRAINT `user_behaviors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_behaviors`
--

LOCK TABLES `user_behaviors` WRITE;
/*!40000 ALTER TABLE `user_behaviors` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_behaviors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_locale_settings`
--

DROP TABLE IF EXISTS `user_locale_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_locale_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language_id` bigint unsigned NOT NULL,
  `currency_id` bigint unsigned NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_locale_settings_language_id_foreign` (`language_id`),
  KEY `user_locale_settings_currency_id_foreign` (`currency_id`),
  KEY `user_locale_settings_user_id_session_id_index` (`user_id`,`session_id`),
  CONSTRAINT `user_locale_settings_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `user_locale_settings_language_id_foreign` FOREIGN KEY (`language_id`) REFERENCES `languages` (`id`),
  CONSTRAINT `user_locale_settings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_locale_settings`
--

LOCK TABLES `user_locale_settings` WRITE;
/*!40000 ALTER TABLE `user_locale_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_locale_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_points`
--

DROP TABLE IF EXISTS `user_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_points` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `points` int NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_id` bigint unsigned DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_points_order_id_foreign` (`order_id`),
  KEY `user_points_user_id_type_index` (`user_id`,`type`),
  KEY `user_points_expires_at_index` (`expires_at`),
  CONSTRAINT `user_points_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `user_points_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_points`
--

LOCK TABLES `user_points` WRITE;
/*!40000 ALTER TABLE `user_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_points` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `encrypted_phone` text COLLATE utf8mb4_unicode_ci,
  `encrypted_address` text COLLATE utf8mb4_unicode_ci,
  `encrypted_notes` text COLLATE utf8mb4_unicode_ci,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `session_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `ban_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ban_description` text COLLATE utf8mb4_unicode_ci,
  `banned_at` timestamp NULL DEFAULT NULL,
  `ban_expires_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_email_index` (`email`),
  KEY `users_created_at_index` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_logs`
--

DROP TABLE IF EXISTS `webhook_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `webhook_id` bigint unsigned NOT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhook_logs_webhook_id_index` (`webhook_id`),
  CONSTRAINT `webhook_logs_webhook_id_foreign` FOREIGN KEY (`webhook_id`) REFERENCES `webhooks` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_logs`
--

LOCK TABLES `webhook_logs` WRITE;
/*!40000 ALTER TABLE `webhook_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhooks`
--

DROP TABLE IF EXISTS `webhooks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhooks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `store_identifier` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_identifier` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `payload` json NOT NULL,
  `signature` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','processing','completed','failed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `error_message` text COLLATE utf8mb4_unicode_ci,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `webhooks_product_id_foreign` (`product_id`),
  KEY `webhooks_store_identifier_event_type_index` (`store_identifier`,`event_type`),
  KEY `webhooks_status_created_at_index` (`status`,`created_at`),
  KEY `webhooks_store_identifier_index` (`store_identifier`),
  KEY `webhooks_event_type_index` (`event_type`),
  KEY `webhooks_status_index` (`status`),
  CONSTRAINT `webhooks_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhooks`
--

LOCK TABLES `webhooks` WRITE;
/*!40000 ALTER TABLE `webhooks` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhooks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `wishlists` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `wishlists_user_id_product_id_unique` (`user_id`,`product_id`),
  UNIQUE KEY `wishlists_user_product_unique` (`user_id`,`product_id`),
  KEY `wishlists_user_id_index` (`user_id`),
  KEY `wishlists_product_id_index` (`product_id`),
  CONSTRAINT `wishlists_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wishlists`
--

LOCK TABLES `wishlists` WRITE;
/*!40000 ALTER TABLE `wishlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `wishlists` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-10-13  9:54:01
