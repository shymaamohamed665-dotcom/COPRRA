<?php

declare(strict_types=1);

namespace App\Http\Controllers;

class LocaleController extends Controller
{
    // تم حذف المتغير غير المستخدم من هنا
}
