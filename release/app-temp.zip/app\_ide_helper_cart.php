<?php

declare(strict_types=1);

namespace Darryldecode\Cart\Facades;

/**
 * @mixin \Darryldecode\Cart\Cart
 */
class CartFacade
{
}
